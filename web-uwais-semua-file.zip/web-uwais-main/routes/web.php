<?php

use App\Http\Controllers\VisionsController;
use App\Models\Vision;
use App\Http\Controllers\ServicesController;
use App\Models\Service;
use App\Http\Controllers\CompetenciesController;
use App\Models\Competency;
use App\Http\Controllers\BannersController;
use App\Models\Banner;
use App\Models\Cloudservice;
use App\Http\Controllers\CloudservicesController;
use App\Models\Contact;
use App\Http\Controllers\ContactsController;
use App\Http\Controllers\ProfileController;
use App\Models\About;
use App\Http\Controllers\AboutsController;
use App\Models\Philosophy;
use App\Http\Controllers\PhilosophiesController;
use App\Models\Internetpackage; 
use App\Http\Controllers\InternetpackagesController;
use App\Models\Imagecategory;
use App\Http\Controllers\ImagecategoriesController;
use App\Models\Partner;
use App\Http\Controllers\PartnersController; 
use App\Http\Controllers\UsersController;
use App\Http\Controllers\Auth\RegisteredUserController; // NEW

// Rute Publik Anda
Route::get('/', function () {
    $visions = Vision::active()->where('location', 'home')->get();
    $services = Service::all();
    $competencies = Competency::all();
    $banners = Banner::active()->where('location', 'home')->get();
    $contacts = Contact::all();

    return view('public.index',
        compact('visions',
                'services',
                'competencies',
                'banners',
                'contacts',
                
    ));
});
Route::get('/about', function () {
    $banners = Banner::active()->where('location', 'about')->get();
    $abouts = About::all();
    $visions = Vision::active()->where('location', 'about')->get();
    $contacts = Contact::all();
    $philosophies = Philosophy::active()->get();
    $images = Imagecategory::active()->get();
    $partners = Partner::active()->get();
    return view('public/about',
    compact(
        'banners',
        'abouts',
        'visions',
        'contacts',
        'philosophies',
        'images',
        'partners',
    ));
    });

Route::get('/internetpackage', function () {
    $banners = Banner::active()->where('location', 'internet_Package')->get();
    $boardbands = Internetpackage::where('location', 'Paket_Boardband')->orderBy('order', 'asc')->get(); 
    $dedicates = Internetpackage::where('location', 'Paket_Dedicate')->orderBy('order', 'asc')->get(); 
    $dedicatelites = Internetpackage::where('location', 'Paket_Dedicate_Lite')->orderBy('order', 'asc')->get(); 
    $contacts = Contact::all();
    
    return view('public/Internetpackage', 
    compact(
        'banners',
        'boardbands',
        'dedicates', 
        'dedicatelites', 
        'contacts',
    ));
    });

Route::get('/cloudservice', function () {
    $banners = Banner::active()->where('location', 'cloud_service')->get();
    $contacts = Contact::all();
    $webs = Cloudservice::active()->where('location', 'web_desa')->get();
    $hostingpackages = Cloudservice::active()->where('location', 'hosting')->get();
    $vpspackages = Cloudservice::active()->where('location', 'vps')->get();
    $co_locations = Cloudservice::active()->where('location', 'co-location')->get();
    
    
    return view('public/cloudservice', 
    compact(
        'banners',
        'webs',
        'hostingpackages',
        'vpspackages',
        'co_locations',
        'contacts',
    ));
    });

Route::get('/internetpackages/second', function () {
    $banners = Banner::active()->where('location', 'product_2')->get();
    
    $contacts = Contact::all();
    return view('public/secondInternetpackage',
    compact(
        'banners',
        'contacts',
    ));
    });

Route::get('/contact', function () {
    $banners = Banner::active()->where('location', 'contact')->get();
    $contacts = Contact::where('location', 'contact')->get();

    return view('public.contact',
        compact('contacts',
                'banners',
    ));
});

// Rute Dashboard Bawaan Breeze
Route::get('admin/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware(['auth'])->group(function () {
    Route::get('/admin/home', function () {return view('layouts/home');});
    Route::get('/admin/about', function () {return view('layouts/about');});
    Route::get('/admin/internetpackages', function () {return view('layouts/internetpackages');});
    Route::get('/admin/contact', function () {return view('layouts/contact');});
    //untuk visi
    Route::resource('admin/vision', VisionsController::class)->names('vision');

    //untuk layanan
    Route::resource('admin/service', ServicesController::class)->names('service');

    //untuk keunggulan
    Route::resource('admin/competency', CompetenciesController::class)->names('competency');

    //untuk banner (Unified)
    Route::resource('admin/banners', BannersController::class)->names('banner');

    //untuk contact
    Route::resource('admin/index/contact', ContactsController::class)->names('contact');

    //untuk about profile
    Route::resource('admin/abouts', AboutsController::class)->names('abouts');

    //untuk philosophies
    Route::resource('admin/philosophies', PhilosophiesController::class)->names('philosophy');

    //untuk philosophies
    Route::resource('admin/imagecategories', ImagecategoriesController::class)->names('imagecategory');
    Route::delete('/admin/image/{image}', [ImagecategoriesController::class, 'destroyImage'])->name('image.destroy');

    //untuk philosophies
    Route::resource('admin/partners',PartnersController::class)->names('partner');
    Route::delete('/admin/partnerimage/{partnerimage}', [PartnersController::class, 'destroyImage'])->name('partnerimage.destroy');


    //untuk fp Home packages (sekarang internetpackages)
    Route::resource('admin/internetpackages', InternetpackagesController::class)->names('internetpackage'); // Diubah

    Route::resource('admin/cloudservices', CloudservicesController::class)->names('cloudservice');

    // User Manager
    Route::resource('admin/users', UsersController::class)->except(['create', 'store'])->names('users');

    // Admin specific registration route (accessible by authenticated users)
    Route::get('/admin/register', [RegisteredUserController::class, 'create'])->name('admin.register');
    Route::post('/admin/register', [RegisteredUserController::class, 'store'])->name('admin.register.store');

    // Rute Profile Bawaan Breeze (juga butuh login)

    // Rute Profile Bawaan Breeze (juga butuh login)
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Rute untuk proses Login, Register, dll. (Jangan Dihapus)
require __DIR__.'/auth.php';