<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::dropIfExists('businesspackages');
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::create('businesspackages', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('description');
            $table->string('price');
            $table->string('period');
            $table->string('featureone');
            $table->string('featuretwo');
            $table->string('featurethree');
            $table->timestamps();
        });
    }
};
