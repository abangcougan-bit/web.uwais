<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('features', function (Blueprint $table) {
            // Drop foreign key first
            $table->dropForeign(['internetboardband_id']);
            // Rename column
            $table->renameColumn('internetboardband_id', 'product_id');
        });

        Schema::table('features', function (Blueprint $table) {
            // Add foreign key back, referencing the new table name 'productcards'
            $table->foreign('product_id')->references('id')->on('productcards')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('features', function (Blueprint $table) {
            // Drop new foreign key first
            $table->dropForeign(['product_id']);
            // Rename column back
            $table->renameColumn('product_id', 'internetboardband_id');
        });

        Schema::table('features', function (Blueprint $table) {
            // Add foreign key back, referencing the old table name 'internetboardbands'
            $table->foreign('internetboardband_id')->references('id')->on('internetboardbands')->onDelete('cascade');
        });
    }
};