<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::dropIfExists('abanners');
        Schema::dropIfExists('fpbanners');
        Schema::dropIfExists('spbanners');
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::create('abanners', function (Blueprint $table) {
            $table->id();
            $table->string('image');
            $table->string('title');
            $table->text('description');
            $table->timestamps();
        });
        Schema::create('fpbanners', function (Blueprint $table) {
            $table->id();
            $table->string('image');
            $table->string('title');
            $table->text('description');
            $table->timestamps();
        });
        Schema::create('spbanners', function (Blueprint $table) {
            $table->id();
            $table->string('image');
            $table->string('title');
            $table->text('description');
            $table->timestamps();
        });
    }
};
