<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('internetboardbands', function (Blueprint $table) {
            $table->dropColumn(['featureone', 'featuretwo', 'featurethree']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('internetboardbands', function (Blueprint $table) {
            $table->string('featureone')->nullable();
            $table->string('featuretwo')->nullable();
            $table->string('featurethree')->nullable();
        });
    }
};
