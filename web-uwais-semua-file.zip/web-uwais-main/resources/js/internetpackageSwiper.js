import Swiper from "swiper";
import { Pagination, Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";

const swiper = new Swiper(".package", {
    modules: [Pagination, Navigation],
    loop: false,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },

    breakpoints: {
        2560: {
            slidesPerView: 5,
            spaceBetween: 40,
            centeredSlides: false,
        },
        1440: {
            slidesPerView: 3.3,
            spaceBetween: 30,
            centeredSlides: false,
        },
        1024: {
            slidesPerView: 3,
            spaceBetween: 30,
            centeredSlides: false,
        },
        640: {
            slidesPerView: 2,
            spaceBetween: 20,
            centeredSlides: false,
        },
        320: {
            slidesPerView: 1,
            spaceBetween: 10,
            centeredSlides: true,
        },
    },
});
