import "./bootstrap";
import Alpine from "alpinejs";
window.Alpine = Alpine;
Alpine.start();
import "./internetpackageSwiper";
import "@fontsource/plus-jakarta-sans";
