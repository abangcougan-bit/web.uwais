@extends('layouts.public')

@section('title', 'about')

@push('styles')
@endpush

@section('header')
    @include('layouts.header')
@endsection



@section('content')
    <div class="w-full h-full">
        <!--banner-->
        <div class="md:w-9/12 w-11/12 m-auto h-full overflow-hidden border-b-2 mb-20 mt-16 p-4 flex items-center justify-center">
            @foreach($banners as $banner)
            <div class="w-full md:min-h-[80vh] min-h-[40vh] grid lg:grid-cols-2 grid-cols-1">
    
                <div class="bg-transparent w-full min-h-10 p-4 flex flex-col md:gap-5 gap-1 justify-center">
                    <h1 class="font-bold lg:text-6xl sm:text-5xl text-2xl">{{$banner ->  title}}</h1>
                    <p class="w-full md:text-xl text-sm break-words ">{{$banner -> description}}</p>
                </div>

                <div class="bg-transparent w-full md:min-h-96 min-h-10 flex items-center justify-center">
                    <img src="{{ asset('storage/' . $banner->image) }}" alt="" class="object-center object-contain w-full h-full">
                </div>
            </div>
            @endforeach
        </div>

        <!--profil-->
        <div class="md:w-full w-11/12 h-full p-4 mt-10 m-auto" id="profile">
            @foreach($abouts->sortByDesc('created_at')->take(1) as $about)
            
            <div class="w-full h-full flex flex-col gap-4 items-center">
                <h1 class="font-semibold md:text-6xl text-2xl">{{$about->title}}</h1>
                <div class="prose">{!!$about->description!!}</div>
            </div>
            @endforeach
        </div>

        <!--visi misi-->
        <div class="md:w-full w-11/12 h-full p-4 m-auto mt-20" id="visiMisi">
            @foreach($visions->sortByDesc('created_at')->take(1) as $vision)
            <div class=" w-full h-full flex flex-col gap-4 items-center">
                <h1 class="font-semibold md:text-6xl text-xl">{{$vision->title}}</h1>
                <div class="prose">{!! $vision->description !!}</div>
            </div>
            @endforeach
        </div>

        <!--filosofi-->
        <div class="md:w-full w-11/12 h-full p-4 m-auto mt-20" id="filosofi">
            @foreach($philosophies->take(1) as $philosophy)
            <div class=" w-full h-full flex flex-col gap-4 items-center">
                <h1 class="font-semibold md:text-6xl text-xl">{{$philosophy->title}}</h1>
                <img src="{{ asset('storage/' . $philosophy->image) }}" alt="" class="2xl:w-7/12 xl:w-9/12 md:w-10/12 object-contain object-center">
                <div class="prose">{!!$philosophy->description!!}</div> 
            </div>
            @endforeach
        </div>

        <!--galeri-->
        <div class="2xl:w-11/12 m-auto w-full h-full flex flex-col gap-10 lg:pl-10 p-4 mt-20" id="galeri">
            @foreach($images as $image)
            <div class="w-full min-h-96">
                <div class="flex">
                    <div class="grid grid-cols-2 min-w-40">
                        <h1 class="font-bold text-2xl sm:text-3xl">{{$image ->title}}</h1>
                        <svg class="w-9 h-9 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 5 7 7-7 7"/>
                        </svg>
                        <p class="">{{$image ->description}}</p>
                    </div>
                </div>

                <div class="py-4 w-full 2xl:h-[40vh] lg:h-[60vh] sm:h-96 h-80 overflow-y-auto grid 2xl:grid-cols-6 lg:grid-cols-5 sm:grid-cols-3 grid-cols-2 gap-4 mt-4  rounded-md">
                    @foreach($image -> images as $photo)
                        <div class="w-full md:h-60 sm:h-50 h-40 bg-gray-100 rounded-md shadow-sm drop-shadow-md duration-300 bg-no-repeat bg-center bg-cover hover:-translate-y-1 "
                        style="background-image: url({{ asset('storage/' . $photo->image) }});"
                        onclick="openImageModal('{{ asset('storage/' . $photo->image) }}')"></div>
                    @endforeach
                </div>
            </div>
            @endforeach
        </div>

        <!--modal gambar-->
        <div id="imageModal" class="fixed bg-black/80 z-30 w-full h-screen inset-0 hidden overflow-auto p-4"
        onclick="closeImageModal()">
                <img id="modalImage" src="" alt="Full size image" class="w-full h-full object-contain rounded-lg">

        </div>

        <!--partners-->
        <div class="flex flex-col w-full min-h-96 mt-32 p-4 items-center gap-20" id="support">
                @foreach($partners as $partner)
                <div class="flex flex-col items-center w-10/12 gap-4 mb-7">
                    <h1 class="text-3xl font-bold">{{$partner -> title}}</h1>
                    <div class="md:w-2/12 w-5/12 h-0.5 rounded-full bg-gray-400 mb-10"></div>
                    <div class="grid md:grid-cols-4 grid-cols-2 w-full gap-4 h-full">                      
                        @foreach($partner -> partnerimages as $partnerimage)
                            <div class="w-full h-20 bg-transparent bg-no-repeat bg-center bg-contain"
                            style="background-image: url({{ asset('storage/' . $partnerimage->image) }});">

                            </div>
                        @endforeach
                    </div>
                    <div class="w-full h-0.5 rounded-full bg-gray-400 mt-5"></div>
                </div>
                @endforeach

        </div>
        
    </div>
@endsection



@section('footer')
    @include('layouts.footer')
@endsection

@push('scripts')
<script>
    const imageModal = document.getElementById("imageModal");
    const modalImage = document.getElementById("modalImage");
    function openImageModal(imageUrl) {
        modalImage.src = imageUrl;
        imageModal.classList.remove("hidden");
    }
    function closeImageModal() {
        modalImage.src = "";
        imageModal.classList.add("hidden");
    }
</script>
@endpush
