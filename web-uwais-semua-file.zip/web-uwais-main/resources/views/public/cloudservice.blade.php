@extends('layouts.public')

@section('title', 'Cloud Service')

@push('styles')

@endpush

@section('header')
    @include('layouts.header')
@endsection

@section('content')
<div class="w-full mb-20">

    <!--banner-->
        <div class="md:w-9/12 w-11/12 m-auto h-full overflow-hidden border-b-2 mb-20 mt-16 p-4 flex items-center justify-center">
            @foreach($banners as $banner)
            <div class="w-full md:min-h-[80vh] min-h-[40vh] grid lg:grid-cols-2 grid-cols-1">
    
                <div class="bg-transparent w-full min-h-10 p-4 flex flex-col md:gap-5 gap-1 justify-center">
                    <h1 class="font-bold lg:text-6xl sm:text-5xl text-2xl">{{$banner ->  title}}</h1>
                    <p class="w-full md:text-xl text-sm break-words ">{{$banner -> description}}</p>
                </div>

                <div class="bg-transparent w-full md:min-h-96 min-h-10 flex items-center justify-center">
                    <img src="{{ asset('storage/' . $banner->image) }}" alt="" class="object-center object-contain w-full h-full">
                </div>
            </div>
            @endforeach
        </div>

    <!--web desa-->
    <div class="w-full h-full p-4 m-auto flex flex-col items-center">
        <h1 class="font-semibold sm:text-5xl text-2xl ">Website Desa</h1>
        <p class="text-center sm:text-lg text-sm ">Ayo level up desa mu, kami siap membantu kapan pun itu.</p>

        <div class="2xl:w-5/12 xl:w-9/12 w-11/12 grid lg:grid-cols-3 sm:grid-cols-2 gap-4 mt-8 ">
        @foreach($webs as $web)
        <div class="w-full min-h-96 border shadow-lg rounded-lg hover:-translate-y-2 duration-700 p-4">
            <img src="{{ asset('storage/' . $web->image) }}" alt="" class="w-24 h-24 object-center object-contain">
            <h1 class="text-2xl font-bold">{{$web -> title}}</h1>
            <p class="">{{$web -> description}}</p>
        </div>
        @endforeach
        </div>

        <a href="https://wa.me/6282324543649" target="_blank" class=" w-40 h-12 rounded-full flex items-center justify-center bg-gradient-to-r from-blue-700 to-blue-500 mt-4">
        <button class="font-bold text-lg text-white">
            
                Klik Disini
           
        </button>
        </a>
    </div>

    <!--hosting-->
    <div class="w-full h-full p-4 m-auto flex flex-col items-center mt-10">
        <h1 class="font-semibold sm:text-5xl text-2xl">Hosting</h1>
        <p class="text-center sm:text-lg text-sm">Kami menghadirkan layanan hosting dengan infrastruktur modern yang menjamin kecepatan akses optimal dan sistem keamanan berlapis.</p>

        <div class="2xl:w-5/12 xl:w-9/12 w-11/12 grid lg:grid-cols-3 sm:grid-cols-2 gap-4 mt-8 ">
        @foreach($hostingpackages as $hosting)
        <div class="w-full p-4 min-h-96 border shadow-lg rounded-lg hover:-translate-y-2 duration-700">
    
            <img src="{{ asset('storage/' . $hosting->image) }}" alt="" class="w-24 h-24 object-center object-contain">
            <h1 class="text-2xl font-bold">{{$hosting -> title}}</h1>
            <p class="">{{$hosting -> description}}</p>
            
        </div>
        @endforeach
        </div>

        <a href="https://wa.me/6282324543649" target="_blank" class=" w-40 h-12 rounded-full flex items-center justify-center bg-gradient-to-r from-blue-700 to-blue-500 mt-4">
        <button class="font-bold text-lg text-white">
            
                Klik Disini
           
        </button>
        </a>
    </div>

    <!--VPS-->
    <div class="w-full h-full p-4 m-auto flex flex-col items-center mt-10">
        <h1 class="font-semibold sm:text-5xl text-2xl">VPS</h1>
        <p class="text-center sm:text-lg text-sm">Naikkan standar operasional Anda dengan Virtual Private Server (VPS) yang memberikan privasi dan sumber daya terdedikasi sepenuhnya untuk Anda.</p>

        <div class="2xl:w-5/12 xl:w-9/12 w-11/12 grid lg:grid-cols-3 sm:grid-cols-2 gap-4 mt-8 ">
         @foreach($vpspackages as $vps)
        <div class="w-full min-h-96 border p-4 shadow-lg rounded-lg hover:-translate-y-2 duration-700">
            <img src="{{ asset('storage/' . $vps->image) }}" alt="" class="w-24 h-24 object-center object-contain">
            <h1 class="text-2xl font-bold">{{$vps -> title}}</h1>
            <p class="">{{$vps -> description}}</p>
        </div>
        @endforeach
        </div>

        <a href="https://wa.me/6282324543649" target="_blank" class=" w-40 h-12 rounded-full flex items-center justify-center bg-gradient-to-r from-blue-700 to-blue-500 mt-4">
        <button class="font-bold text-lg text-white">
            
                Klik Disini
           
        </button>
        </a>
    </div>

    <!--Co-location-->
    <div class="w-full h-full p-4 m-auto flex flex-col items-center mt-10">
        <h1 class="font-semibold sm:text-5xl text-2xl">Co-location</h1>
        <p class="text-center sm:text-lg text-sm">Maksimalkan masa pakai dan kinerja perangkat server Anda dengan menitipkannya di fasilitas data center kami yang bersertifikasi.</p>

        <div class="2xl:w-5/12 xl:w-9/12 w-11/12 grid lg:grid-cols-3 sm:grid-cols-2 gap-4 mt-8 ">
        @foreach($co_locations as $co_location)
        <div class="w-full min-h-96 border shadow-lg p-4 rounded-lg hover:-translate-y-2 duration-700">
            <img src="{{ asset('storage/' . $co_location->image) }}" alt="" class="w-24 h-24 object-center object-contain">
            <h1 class="text-2xl font-bold">{{$co_location -> title}}</h1>
            <p class="">{{$co_location -> description}}</p>
        </div>
        @endforeach
        </div>

        <a href="https://wa.me/6282324543649" target="_blank" class=" w-40 h-12 rounded-full flex items-center justify-center bg-gradient-to-r from-blue-700 to-blue-500 mt-4">
        <button class="font-bold text-lg text-white">
            
                Klik Disini
           
        </button>
        </a>
    </div>

    
</div>
@endsection

@section('footer')
    @include('layouts.footer')
@endsection

@push('scripts')

@endpush