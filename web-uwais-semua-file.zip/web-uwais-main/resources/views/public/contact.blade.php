@extends('layouts.public')

@section('title', 'Contact')

@push('styles')
@endpush

@section('header')
    @include('layouts.header')
@endsection

@section('content')
    <div class="w-full">
        <!--banner-->
        <div class="md:w-9/12 w-11/12 m-auto h-full overflow-hidden border-b-2 mb-16 mt-16 p-4 flex items-center justify-center">
            @foreach($banners as $banner)
            <div class="w-full md:min-h-[80vh] min-h-[40vh] grid lg:grid-cols-2 grid-cols-1">
    
                <div class="bg-transparent w-full min-h-10 p-4 flex flex-col md:gap-5 gap-1 justify-center">
                    <h1 class="font-bold lg:text-6xl sm:text-5xl text-2xl">{{$banner ->  title}}</h1>
                    <p class="w-full md:text-xl text-sm break-words ">{{$banner -> description}}</p>
                </div>

                <div class="bg-transparent w-full md:min-h-96 min-h-10 flex items-center justify-center">
                    <img src="{{ asset('storage/' . $banner->image) }}" alt="" class="object-center object-contain w-full h-full">
                </div>
            </div>
            @endforeach
        </div>
        
            
            <!--Contact-->
            <div class="2xl:w-9/12 m-auto w-full h-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 p-4 gap-4">
                @foreach($contacts as $contact)
                <a href="{{$contact -> url}}" target="_blank">
                    <div class="group border rounded-md shadow-md drop-shadow-md transition-all duration-700 hover:bg-blue-900 hover:border-gray-500 sm:w-full w-72 m-auto sm:min-h-72 min-h-52 justify-center items-center flex flex-col gap-2 p-0.5">

                        <div class="flex w-full h-20 justify-center ">
                            <div class="rounded-full sm:w-24 w-20 sm:h-24 h-20 bg-cover bg-center bg-no-repeat group-hover:invert transition-all duration-700"
                            style="background-image: url({{ asset('storage/' . $contact->image) }});">
                                
                            </div>
                        </div>

                        <div class="flex flex-col w-full justify-center items-center gap-2 ">
                            <h1 class="text-xl font-semibold w-10/12 break-words text-center group-hover:text-white transition-all duration-700">{{$contact->title}}</h1>
                            <div class="w-7/12 h-0.5 bg-black rounded-full group-hover:bg-white transition-all duration-700"></div>
                        </div>

                        <div class="w-full h-full flex justify-center group-hover:text-white transition-all duration-700">
                            <p class="text-lg text-center">{{$contact->description}}</p>
                        </div>
                    </div>
                </a>
            @endforeach
            </div>
    </div>

@endsection

@section('footer')
    @include('layouts.footer')
@endsection

@push('scripts')
    
@endpush