@extends('layouts.public')

@section('title', 'Internet Service Provider')

@push('styles')

@endpush

@section('header')
    @include('layouts.header')
@endsection

@section('content')
<div class="w-full">

    <!--banner-->
        <div class="md:w-9/12 w-11/12 m-auto h-full overflow-hidden border-b-2 mb-20 mt-16 p-4 flex items-center justify-center">
            @foreach($banners as $banner)
            <div class="w-full md:min-h-[80vh] min-h-[40vh]  grid lg:grid-cols-2 grid-cols-1">
    
                <div class="bg-transparent w-full min-h-10 p-4 flex flex-col md:gap-5 gap-1 justify-center">
                    <h1 class="font-bold sm:text-5xl text-2xl">{{$banner ->  title}}</h1>
                    <p class="w-full md:text-xl text-sm break-words ">{{$banner -> description}}</p>
                </div>

                <div class="bg-transparent w-full md:min-h-96 min-h-10 flex items-center justify-center">
                    <img src="{{ asset('storage/' . $banner->image) }}" alt="" class="object-center object-contain w-full h-full">
                </div>
            </div>
            @endforeach
        </div>
    
    <!--internet boardband-->
    <div class="w-full min-h-96 m-auto flex flex-col items-center">
        <h1 class="font-semibold sm:text-5xl text-2xl">Internet Boardband</h1>
        <p class="text-center">Sambungan internet via wireless dan kabel serat optik yang cocok untuk pelanggan rumahan atau kantor skala kecil</p>

        
    <div class="swiper package !px-4 md:!px-10 w-11/12 mt-10">
        <div class="swiper-wrapper">
            @foreach($boardbands as $boardband)
                <div class="swiper-slide flex flex-col bg-white shadow-lg rounded-lg mb-4">
                    <div class="bg-blue-900 h-20 rounded-t-lg w-full flex flex-col items-center justify-center p-4 text-white">
                        <h1 class="text-3xl font-semibold">{{$boardband -> title}}</h1>
                        <p class="text-sm font-medium">{{$boardband -> description }}</p>
                    </div>
                    <div class="p-4 w-full min-h-80 flex flex-col items-center">
                        <h1 class="sm:text-5xl text-4xl  font-medium"><sup class="sm:text-xl text-lg">Rp</sup>{{$boardband -> price}}</h1>
                        <h6 class="mb-5">{{$boardband -> period}}</h6>

                        @foreach($boardband->features as $feature)

                            <div class="flex w-11/12 border-b-2 mb-6 items-center">
                                <svg class="w-5 h-5 sm:h-6 sm:w-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.5 11.5 11 14l4-4m6 2a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"/>
                                    </svg>
                                    <p class="text-sm sm:text-base">{{$feature -> description}}</p>
                            </div>
                            
                        @endforeach

                       
                        <a href="https://daftar.uwais.net.id/home" target="_blank" class="w-5/12 bg-blue-900 rounded-full h-10 flex items-center justify-center mt-5">
                            <h2 class="sm:text-base text-sm font-semibold text-white">Klik Disini</h2>
                        </a>

                    </div>
                </div>
            @endforeach
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
    </div>

    

    </div>

    <!--Internet Dedicate-->
    <div class="w-full min-h-96 m-auto flex flex-col items-center mt-20">
        <h1 class="font-semibold sm:text-5xl text-2xl">Internet Dedicate</h1>
        <p class="text-center">Sambungan internet serat optik dengan kapasitas besar dan IP Public Static untuk keperluan bisnis anda</p>

        <div class="swiper package  !px-4 md:!px-10 w-11/12 mt-10">
        <div class="swiper-wrapper">
            @foreach($dedicates as $dedicate)
                <div class="swiper-slide flex flex-col bg-white shadow-lg rounded-lg mb-4">
                    <div class="bg-blue-900 h-20 rounded-t-lg w-full flex flex-col items-center justify-center p-4 text-white">
                        <h1 class="text-3xl font-semibold">{{$dedicate -> title}}</h1>
                        <p class="text-sm font-medium">{{$dedicate -> description }}</p>
                    </div>
                    <div class="p-4 w-full min-h-80 flex flex-col items-center">
                        <h1 class="sm:text-5xl text-4xl  font-medium"><sup class="sm:text-xl text-lg">Rp</sup>{{$dedicate -> price}}</h1>
                        <h6 class="mb-5">{{$dedicate -> period}}</h6>

                        @foreach($dedicate->features as $feature)

                            <div class="flex w-11/12 border-b-2 mb-6 items-center">
                                <svg class="w-5 h-5 sm:h-6 sm:w-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.5 11.5 11 14l4-4m6 2a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"/>
                                    </svg>
                                    <p class="text-sm sm:text-base">{{$feature -> description}}</p>
                            </div>
                            
                        @endforeach

                       
                        <a href="https://wa.me/6282324543649" target="_blank" class="w-5/12 bg-blue-900 rounded-full h-10 flex items-center justify-center mt-5">
                            <h2 class="sm:text-base text-sm font-semibold text-white">Klik Disini</h2>
                        </a>

                    </div>
                </div>
            @endforeach
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
    </div>

    </div>

    <!--Internet Dedicate Lite-->
    <div class="w-full min-h-96 m-auto flex flex-col items-center mt-20">
        <h1 class="font-semibold sm:text-5xl text-2xl">Internet Dedicate Lite</h1>
        <p class="text-center">Sambungan internet serat optik dengan kapasitas besar dan IP Public Static untuk keperluan bisnis anda</p>
     
    <div class="swiper package !px-4 md:!px-10 w-11/12 mt-10">
        <div class="swiper-wrapper">
            @foreach($dedicatelites as $dedicatelite)
                <div class="swiper-slide flex flex-col bg-white shadow-lg rounded-lg mb-4">
                    <div class="bg-blue-900 h-20 rounded-t-lg w-full flex flex-col items-center justify-center p-4 text-white">
                        <h1 class="text-3xl font-semibold">{{$dedicatelite -> title}}</h1>
                        <p class="text-sm font-medium">{{$dedicatelite -> description }}</p>
                    </div>
                    <div class="p-4 w-full min-h-80 flex flex-col items-center">
                        <h1 class="sm:text-5xl text-4xl  font-medium"><sup class="sm:text-xl text-lg">Rp</sup>{{$dedicatelite -> price}}</h1>
                        <h6 class="mb-5">{{$dedicatelite -> period}}</h6>

                        @foreach($dedicatelite->features as $feature)

                            <div class="flex w-11/12 border-b-2 mb-6 items-center">
                                <svg class="w-5 h-5 sm:h-6 sm:w-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.5 11.5 11 14l4-4m6 2a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"/>
                                    </svg>
                                    <p class="text-sm sm:text-base">{{$feature -> description}}</p>
                            </div>
                            
                        @endforeach

                       
                        <a href="https://wa.me/6282324543649" target="_blank" class="w-5/12 bg-blue-900 rounded-full h-10 flex items-center justify-center mt-5">
                            <h2 class="sm:text-base text-sm  font-semibold text-white">Klik Disini</h2>
                        </a>

                    </div>
                </div>
            @endforeach
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
    </div>

    </div>
    
</div>
@endsection

@section('footer')
    @include('layouts.footer')
@endsection

@push('scripts')

@endpush