@extends('layouts.public')

@section('title', 'Home')

@push('styles')
@endpush

@section('header')
    @include('layouts.header')
@endsection

@section('content')
<div class="w-full h-full">

    <!--banner-->
        <div class="md:w-9/12 w-11/12 m-auto h-full overflow-hidden border-b-2 mb-20 mt-16 p-4 flex items-center justify-center">
            @foreach($banners as $banner)
            <div class="w-full md:min-h-[80vh] min-h-[40vh] grid lg:grid-cols-2 grid-cols-1">
    
                <div class="bg-transparent w-full min-h-10 p-4 flex flex-col md:gap-5 gap-1 justify-center">
                    <h1 class="font-bold lg:text-6xl sm:text-5xl text-2xl">{{$banner ->  title}}</h1>
                    <p class="w-full md:text-xl text-sm break-words ">{{$banner -> description}}</p>
                </div>

                <div class="bg-transparent w-full md:min-h-96 min-h-10 flex items-center justify-center">
                    <img src="{{ asset('storage/' . $banner->image) }}" alt="" class="object-center object-contain w-full h-full">
                </div>
            </div>
            @endforeach
        </div>

    <!-- Vision -->
    <div class="w-full h-full flex flex-col gap-4" id="visi">
        <!--judul-->
        <div class="flex flex-col md:w-full w-11/12 h-full items-center sm:gap-4 gap-2 m-auto">
            <h1 class="sm:text-6xl text-2xl font-medium">Visi Kami</h1>
            <p class="text-center md:text-lg text-sm">Memastikan bahwa teknologi canggih dapat diakses oleh semua lapisan masyarakat, mengurangi kesenjangan digital, dan memberikan manfaat kepada semua orang.</p>
        </div>
        <!--kotak-->
        <div class="2xl:w-7/12 xl:w-10/12 md:w-11/12 w-9/12 min-h-96 m-auto grid lg:grid-cols-3 sm:grid-cols-2 grid-cols-1 sm:gap-x-10 gap-0">
            @foreach($visions as $visi)
                <div class="bg-transparent w-full h-full flex flex-col items-center group">
                    <div class="bg-transparent w-full sm:h-64 h-56 rounded-lg shadow-sm drop-shadow-lg overflow-hidden bg-white">
                         <img src="{{ asset('storage/' . $visi->image) }}" alt="" class="object-contain object-center h-full w-full duration-700 ">
                        
                    </div>
                    
                    <div class="bg-white group-hover:bg-blue-900 group-hover:text-white w-11/12 min-h-44 group-hover:-translate-y-10 -translate-y-20  p-5 flex flex-col gap-2 rounded-lg shadow-md drop-shadow-lg duration-700 transition-all overflow-hidden">
                        <div class="flex flex-row gap-2 items-center ">
                            <div class="bg-blue-900 w-1 h-8 group-hover:bg-white duration-700 rounded-full"></div>
                            <h1 class="font-semibold text-xl  ">{{$visi->title}}</h1>
                        </div>
                        <p class="break-words">{!!$visi->description!!}</p>
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    <!--Layanan-->
    <div class="w-full p-4 mt-10 flex flex-col items-center gap-8" id="layanan">
        <div class="flex flex-col w-full h-full items-center sm:gap-4 gap-2">
            <h1 class="sm:text-6xl text-2xl font-medium">Layanan Kami</h1>
            <p class="text-center md:text-lg text-sm">Sebagai penyedia internet service provider yang terpercaya, kami menyediakan ekosistem layanan digital yang komprehensif dari koneksi internet yang andal hingga infrastruktur cloud dan sistem manajemen kehadiran.</p>
        </div>
        <div class="2xl:w-8/12 xl:w-10/12 w-10/12 lg:w-11/12 m-auto min-h-full grid lg:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-4">
            @foreach($services as $service)
            <div class="w-full border shadow-lg min-h-80 flex flex-col rounded-lg duration-700 group hover:-translate-y-2 p-4">
                <img src="{{ asset('storage/' . $service->image) }}" alt="" class="w-24 h-24 object-contain object-center">
                <h1 class="text-2xl font-bold ">{{$service -> title}}</h1>
                <p class="">{{$service->description}}</p>
            </div>
            @endforeach
        </div>
    </div>
    
    <!--competency-->
    <div class="flex flex-col w-full h-full p-4 sm:gap-5 gap-2 mt-32" id="keunggulan">
        <div class="flex flex-col w-full h-full items-center gap-4">
            <h1 class="sm:text-6xl text-2xl font-medium">Keunggulan Kami</h1>
            <p class="text-center md:text-lg text-sm">Sebagai penyedia internet service provider yang terpercaya, kami menyediakan ekosistem layanan digital yang komprehensif dari koneksi internet yang andal hingga infrastruktur cloud dan sistem manajemen kehadiran.</p>
        </div>

        <div class="2xl:w-8/12 xl:w-10/12 lg:w-full w-10/12 grid md:grid-cols-2 lg:grid-cols-3 grid-cols-1 min-h-full m-auto md:gap-20 lg:gap-4">
            @foreach($competencies as $competency)
            <div class="flex flex-col w-full gap-1 group">
               
                <div class=" min-h-80 lg:min-h-96 flex flex-col gap-4 p-4 items-center md:text-black/10 group-hover:text-black/100 duration-700">
                    <div class="bg-transparent w-44 h-32 md:group-hover:opacity-10 duration-700 bg-center bg-no-repeat bg-cover"
                    style="background-image: url({{ asset('storage/' . $competency->image) }});"></div>
                    <h1 class="text-2xl font-semibold">{{$competency -> title}}</h1>
                    <p class="text-center">{{$competency -> description}}</p>
                </div>
                <div class="w-full h-0.5 md:bg-gray-300 bg-blue-900 rounded-full group-hover:bg-blue-900 transition-colors duration-700"></div>
            </div>
            @endforeach
        </div>
    </div>

</div>
@endsection

@section('footer')
    @include('layouts.footer')
@endsection

@push('scripts')
@endpush