<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Buat Partner Baru') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form action="{{ route('partner.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf

                        {{-- Judul --}}
                        <div class="mt-4">
                            <x-input-label for="title" :value="__('Judul')" />
                            <x-text-input id="title" class="block mt-1 w-full" type="text" name="title" :value="old('title')" required autofocus />
                            <x-input-error :messages="$errors->get('title')" class="mt-2" />
                        </div>

                        {{-- Deskripsi --}}
                        <div class="mt-4">
                            <x-input-label for="description" :value="__('Deskripsi')" />
                            <textarea id="description" name="description" class="block mt-1 w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">{{ old('description') }}</textarea>
                            <x-input-error :messages="$errors->get('description')" class="mt-2" />
                        </div>

                        {{-- Status --}}
                        <div class="mt-4">
                            <x-input-label :value="__('Status')" />
                            <div class="flex items-center gap-4 mt-2">
                                <input type="radio" name="is_active" id="is_active_true" value="1" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" checked>
                                <label for="is_active_true" class="text-sm text-gray-900">Aktif</label>

                                <input type="radio" name="is_active" id="is_active_false" value="0" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500">
                                <label for="is_active_false" class="text-sm text-gray-900">Tidak Aktif</label>
                            </div>
                            <x-input-error :messages="$errors->get('is_active')" class="mt-2" />
                        </div>

                        {{-- Bagian untuk Gambar Dinamis --}}
                        <div class="mt-4">
                            <x-input-label :value="__('Gambar')" />
                            <div id="partnerimages-container">
                                {{-- Input Awal --}}
                                <div class="flex items-center mt-2 mb-2">
                                    <label class="flex flex-col items-center justify-center w-full h-16 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                                        <div class="flex flex-col items-center justify-center pt-5 pb-6">
                                            <p class="mb-2 text-sm text-gray-500"><span class="font-semibold">Klik Untuk Mengunggah Gambar</span></p>
                                        </div>
                                        <input type="file" name="partnerimages[]" class="hidden" accept="image/*"/>
                                    </label>
                                    {{-- Tombol hapus tidak ada untuk input pertama --}}
                                </div>
                            </div>
                             <x-input-error :messages="$errors->get('partnerimages')" class="mt-2" />
                             <x-input-error :messages="$errors->get('partnerimages.*')" class="mt-2" />

                            <x-secondary-button type="button" id="add-partnerimage-btn" class="mt-2">
                                {{ __('Tambah Gambar Partner Lain') }}
                            </x-secondary-button>
                        </div>
                        {{-- Akhir Bagian untuk Gambar Dinamis --}}

                        <div class="flex items-center justify-end mt-4">
                            <a href="{{route('partner.index')}}" class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                {{ __('Batal') }}
                            </a>
                            <x-primary-button class="ms-4">
                                {{ __('Buat Partner') }}
                            </x-primary-button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const partnerimagesContainer = document.getElementById('partnerimages-container');
        const addPartnerimageBtn = document.getElementById('add-partnerimage-btn');

        const addPartnerimageInput = () => {
            const partnerimageDiv = document.createElement('div');
            partnerimageDiv.classList.add('flex', 'items-center', 'mt-2', 'mb-2');
            partnerimageDiv.innerHTML = `
                <label class="flex flex-col items-center justify-center w-full h-16 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                    <div class="flex flex-col items-center justify-center pt-5 pb-6">
                        <p class="mb-2 text-sm text-gray-500"><span class="font-semibold">Klik Untuk Mengunggah Gambar</span></p>
                    </div>
                    <input type="file" name="partnerimages[]" class="hidden" accept="image/*"/>
                </label>
                <button type="button" class="remove-partnerimage-btn ml-2 px-3 py-1 bg-red-500 text-white rounded-md hover:bg-red-600">Hapus</button>
            `;
            partnerimagesContainer.appendChild(partnerimageDiv);
        };

        addPartnerimageBtn.addEventListener('click', () => {
            addPartnerimageInput();
        });

        partnerimagesContainer.addEventListener('click', function (event) {
            if (event.target.classList.contains('remove-partnerimage-btn')) {
                event.target.closest('.flex.items.center').remove();
            }
        });
    });
</script>
@endpush
</x-app-layout>