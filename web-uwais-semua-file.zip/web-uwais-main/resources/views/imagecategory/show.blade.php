<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Detail Kategori Gambar') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="mb-4">
                        <x-input-label for="title" :value="__('Judul')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $imagecategory->title }}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label for="description" :value="__('Deskripsi')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $imagecategory->description }}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label :value="__('Status')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $imagecategory->is_active ? 'Aktif' : 'Tidak Aktif' }}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label :value="__('Dibuat Pada')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $imagecategory->created_at->format('d M Y, H:i') }}</div>
                    </div>

                    {{-- Gambar --}}
                    <div class="mt-6">
                        <x-input-label :value="__('Gambar')" />
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-2">
                            @forelse ($imagecategory->images as $image)
                                <div class="relative">
                                    <img src="{{ asset('storage/' . $image->image) }}" alt="Image" class="h-auto max-w-full rounded-lg">
                                </div>
                            @empty
                                <p class="text-sm text-gray-500">Tidak ada gambar untuk kategori ini.</p>
                            @endforelse
                        </div>
                    </div>

                    <div class="flex justify-end mt-6">
                        <a href="{{ route('imagecategory.index') }}">
                            <x-secondary-button>
                                {{ __('Kembali') }}
                            </x-secondary-button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>