<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Detail Filosofi') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    {{-- Gambar Filosofi --}}
                    @if($philosophy->image)
                        <div class="mb-4 text-center">
                            <x-input-label :value="__('Gambar Filosofi')" class="text-center" />
                            <img src="{{ asset('storage/' . $philosophy->image) }}" alt="Gambar Filosofi" class="max-w-full h-auto mx-auto mt-2 rounded-lg border border-gray-200"/>
                        </div>
                    @endif

                    <div class="mb-4">
                        <x-input-label for="title" :value="__('Judul')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $philosophy->title }}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label for="description" :value="__('Deskripsi')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{!! $philosophy->description !!}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label :value="__('Status')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $philosophy->is_active ? 'Aktif' : 'Tidak Aktif' }}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label :value="__('Dibuat Pada')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $philosophy->created_at->format('d M Y, H:i') }}</div>
                    </div>

                    <div class="flex justify-end mt-6">
                        <a href="{{ route('philosophy.index') }}">
                            <x-secondary-button>
                                {{ __('Kembali') }}
                            </x-secondary-button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
