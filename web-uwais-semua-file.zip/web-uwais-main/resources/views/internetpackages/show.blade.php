<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Detail Internet Package') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="mb-4">
                        <x-input-label for="title" :value="__('Judul')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $internetpackage->title }}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label for="description" :value="__('Deskripsi')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $internetpackage->description }}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label for="price" :value="__('Harga')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $internetpackage->price }}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label for="period" :value="__('Periode')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $internetpackage->period }}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label :value="__('Lokasi')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ ucfirst(str_replace('_', ' ', $internetpackage->location)) }}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label :value="__('Status')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $internetpackage->is_active ? 'Aktif' : 'Tidak Aktif' }}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label for="order" :value="__('Order')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $internetpackage->order }}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label :value="__('Dibuat Pada')" />
                        <div class="mt-1 p-2 border rounded-md bg-gray-50">{{ $internetpackage->created_at->format('d M Y, H:i') }}</div>
                    </div>

                    <div class="mb-4">
                        <x-input-label :value="__('Keunggulan')" />
                        @if($internetpackage->features->isNotEmpty())
                            <ul class="list-disc list-inside mt-2 ml-4">
                                @foreach($internetpackage->features as $feature)
                                    <li>{{ $feature->description }}</li>
                                @endforeach
                            </ul>
                        @else
                            <p class="mt-1 text-gray-500">Tidak ada keunggulan.</p>
                        @endif
                    </div>

                    <div class="flex justify-end mt-6">
                        <a href="{{ route('internetpackage.index', ['location' => $internetpackage->location]) }}">
                            <x-secondary-button>
                                {{ __('Kembali') }}
                            </x-secondary-button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
