<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Edit Internet Package') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form action="{{ route('internetpackage.update', $internetpackage->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        {{-- Lokasi --}}
                        <div class="mt-4">
                            <x-input-label for="location" :value="__('Lokasi')" />
                            <select name="location" id="location" class="block mt-1 w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                                @foreach($locations as $loc)
                                    <option value="{{ $loc }}" {{ $internetpackage->location == $loc ? 'selected' : '' }}>
                                        {{ ucfirst(str_replace('_', ' ', $loc)) }}
                                    </option>
                                @endforeach
                            </select>
                            <x-input-error :messages="$errors->get('location')" class="mt-2" />
                        </div>

                        {{-- Judul --}}
                        <div class="mt-4">
                            <x-input-label for="title" :value="__('Judul')" />
                            <x-text-input id="title" class="block mt-1 w-full" type="text" name="title" :value="old('title', $internetpackage->title)" required autofocus />
                            <x-input-error :messages="$errors->get('title')" class="mt-2" />
                        </div>

                        {{-- Deskripsi --}}
                        <div class="mt-4">
                            <x-input-label for="description" :value="__('Deskripsi')" />
                            <textarea id="description" name="description" class="block mt-1 w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">{{ old('description', $internetpackage->description) }}</textarea>
                            <x-input-error :messages="$errors->get('description')" class="mt-2" />
                        </div>

                        {{-- Harga --}}
                        <div class="mt-4">
                            <x-input-label for="price" :value="__('Harga')" />
                            <x-text-input id="price" class="block mt-1 w-full" type="text" name="price" :value="old('price', $internetpackage->price)" required />
                            <x-input-error :messages="$errors->get('price')" class="mt-2" />
                        </div>

                        {{-- Periode --}}
                        <div class="mt-4">
                            <x-input-label for="period" :value="__('Periode')" />
                            <x-text-input id="period" class="block mt-1 w-full" type="text" name="period" :value="old('period', $internetpackage->period)" required />
                            <x-input-error :messages="$errors->get('period')" class="mt-2" />
                        </div>

                        {{-- Status --}}
                        <div class="mt-4">
                            <x-input-label :value="__('Status')" />
                            <div class="flex items-center gap-4 mt-2">
                                <input type="radio" name="is_active" id="is_active_true" value="1" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" {{ $internetpackage->is_active ? 'checked' : '' }}>
                                <label for="is_active_true" class="text-sm text-gray-900">Aktif</label>

                                <input type="radio" name="is_active" id="is_active_false" value="0" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" {{ !$internetpackage->is_active ? 'checked' : '' }}>
                                <label for="is_active_false" class="text-sm text-gray-900">Tidak Aktif</label>
                            </div>
                            <x-input-error :messages="$errors->get('is_active')" class="mt-2" />
                        </div>

                        {{-- Order --}}
                        <div class="mt-4">
                            <x-input-label for="order" :value="__('Urutan')" />
                            <x-text-input id="order" class="block mt-1 w-full" type="number" name="order" :value="old('order', $internetpackage->order)" required />
                            <x-input-error :messages="$errors->get('order')" class="mt-2" />
                        </div>

                        {{-- Bagian untuk Keunggulan Dinamis --}}
                        <div class="mt-4">
                            <x-input-label :value="__('Keunggulan')" />
                            <div id="features-container">
                                @foreach($internetpackage->features as $feature)
                                    <div class="flex items-center mt-2 mb-2">
                                        <x-text-input type="text" name="features[]" class="w-full" placeholder="Masukkan keunggulan" value="{{ old('features[]', $feature->description) }}" />
                                        <button type="button" class="remove-feature-btn ml-2 px-3 py-1 bg-red-500 text-white rounded-md hover:bg-red-600">Hapus</button>
                                    </div>
                                @endforeach
                                @if($internetpackage->features->isEmpty())
                                    <div class="flex items-center mt-2 mb-2">
                                        <x-text-input type="text" name="features[]" class="w-full" placeholder="Masukkan keunggulan" />
                                        <button type="button" class="remove-feature-btn ml-2 px-3 py-1 bg-red-500 text-white rounded-md hover:bg-red-600 hidden">Hapus</button>
                                    </div>
                                @endif
                            </div>
                            <x-secondary-button type="button" id="add-feature-btn" class="mt-2">
                                {{ __('Tambah Keunggulan') }}
                            </x-secondary-button>
                        </div>
                        {{-- Akhir Bagian untuk Keunggulan Dinamis --}}

                        <div class="flex items-center justify-end mt-4">
                            <a href="{{route('internetpackage.index',['location' => $internetpackage->location])}}" class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                {{ __('Batal') }}
                            </a>
                            <x-primary-button class="ms-4">
                                {{ __('Update Internet Package') }}
                            </x-primary-button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const featuresContainer = document.getElementById('features-container');
        const addFeatureBtn = document.getElementById('add-feature-btn');

        function addFeatureInput(value = '') {
            const featureDiv = document.createElement('div');
            featureDiv.classList.add('flex', 'items-center', 'mt-2', 'mb-2');
            featureDiv.innerHTML = `
                <input type="text" name="features[]" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" placeholder="Masukkan keunggulan" value="${value}">
                <button type="button" class="remove-feature-btn ml-2 px-3 py-1 bg-red-500 text-white rounded-md hover:bg-red-600">Hapus</button>
            `;
            featuresContainer.appendChild(featureDiv);
        }

        addFeatureBtn.addEventListener('click', function () {
            addFeatureInput();
        });

        featuresContainer.addEventListener('click', function (event) {
            if (event.target.classList.contains('remove-feature-btn')) {
                event.target.closest('.flex.items-center').remove();
            }
        });

        // Show remove button for existing inputs
        featuresContainer.querySelectorAll('.remove-feature-btn').forEach(button => {
            button.classList.remove('hidden');
        });
    });
</script>
@endpush
</x-app-layout>
