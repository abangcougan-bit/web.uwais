<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Edit Layanan') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form action="{{ route('service.update', $service->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {{-- Kolom Kiri: Gambar --}}
    <div class="flex flex-col items-center justify-center p-4 border border-gray-300 rounded-md">
        <div class="w-full h-96 rounded-lg bg-gray-100 flex items-center justify-center overflow-hidden mb-4">
            {{-- Tampilkan gambar yang ada atau pratinjau --}}
            <img id="image-preview" src="{{ $service->image ? asset('storage/' . $service->image) : '#' }}" alt="Pratinjau Gambar" class="{{ $service->image ? '' : 'hidden' }} h-full w-full object-cover rounded-lg"/>
            <span id="placeholder-text" class="{{ $service->image ? 'hidden' : '' }} text-gray-400">Pilih Gambar</span>
        </div>
        <div class="w-full">
            <label for="image" class="flex flex-col items-center justify-center w-full h-16 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                <div class="flex flex-col items-center justify-center pt-5 pb-6">
                    <p class="mb-2 text-sm text-gray-500"><span class="font-semibold">Klik Untuk Mengunggah Gambar Baru</span></p>
                    <p id="file-chosen" class="text-xs text-gray-500">SVG, PNG, JPG atau GIF</p>
                </div>
                <input id="image" type="file" name="image" class="hidden" accept="image/*"/>
            </label>
            <x-input-error :messages="$errors->get('image')" class="mt-2" />
        </div> 
    </div>

                            {{-- Kolom Kanan: Input Form --}}
                            <div class="flex flex-col gap-4">
                                {{-- Judul --}}
                                <div class="mt-4">
                                    <x-input-label for="title" :value="__('Judul')" />
                                    <x-text-input id="title" class="block mt-1 w-full" type="text" name="title" :value="old('title', $service->title)" required autofocus />
                                    <x-input-error :messages="$errors->get('title')" class="mt-2" />
                                </div>

                                {{-- Deskripsi --}}
                                <div class="mt-4">
                                    <x-input-label for="description" :value="__('Deskripsi')" />
                                    <textarea id="description" name="description" class="block mt-1 w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" rows="5">{{ old('description', $service->description) }}</textarea>
                                    <x-input-error :messages="$errors->get('description')" class="mt-2" />
                                </div>

                                {{-- Status --}}
                                <div class="mt-4">
                                    <x-input-label :value="__('Status')" />
                                    <div class="flex items-center gap-4 mt-2">
                                        <input type="radio" name="is_active" id="is_active_true" value="1" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" {{ $service->is_active ? 'checked' : '' }}>
                                        <label for="is_active_true" class="text-sm text-gray-900">Aktif</label>

                                        <input type="radio" name="is_active" id="is_active_false" value="0" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" {{ !$service->is_active ? 'checked' : '' }}>
                                        <label for="is_active_false" class="text-sm text-gray-900">Tidak Aktif</label>
                                    </div>
                                    <x-input-error :messages="$errors->get('is_active')" class="mt-2" />
                                </div>
                            </div>
                        </div>

                        {{-- Tombol Aksi --}}
                        <div class="flex items-center justify-end mt-6">
                            <a href="{{route('service.index')}}" class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                {{ __('Batal') }}
                            </a>
                            <x-primary-button class="ms-4">
                                {{ __('Ubah Layanan') }}
                            </x-primary-button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function(){
const imageInput = document.getElementById('image');
const imagePreview = document.getElementById('image-preview');
const fileChosen = document.getElementById('file-chosen');
const placeholderText = document.getElementById('placeholder-text');
const existingImage = document.getElementById('existing-image');

imageInput.addEventListener('change', function(e){
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event){
            imagePreview.src = event.target.result;
            imagePreview.classList.remove('hidden');
            
            if(placeholderText){
                placeholderText.classList.add('hidden');
            }

            if (existingImage) {
                existingImage.classList.add('hidden');
            }
            fileChosen.textContent = file.name;
        }
        reader.readAsDataURL(file);
    } else {
        // Jika tidak ada file yang dipilih, tampilkan gambar yang sudah ada
        if (existingImage) {
            imagePreview.src = existingImage.src;
        } else {
            imagePreview.src = '#';
            imagePreview.classList.add('hidden');
            if(placeholderText){
                placeholderText.classList.remove('hidden');
            }
        }
        fileChosen.textContent = 'SVG, PNG, JPG atau GIF';
    }
});
});
</script>
@endpush
</x-app-layout>