<div class="w-full h-full border-t mt-20 flex flex-col p-4">

   <div class="w-full h-14 flex items-center justify-center mt-4">
      <div class="flex font-sans opacity-70">
         <img src="{{ asset('assets/images/uwais basic  no bg.png') }}" alt="" class="md:w-24 md:h-24 w-16 h-16">
         <div class="flex flex-col justify-center ">
            <h1 class="md:text-6xl text-3xl font-bold text-blue-900">UWAIS</h1>
            <p class="md:text-2xl text-xs text-blue-900 font-semibold">BORNEO GROUP</p>
         </div>
      </div>
   </div>

   <div class="flex justify-center items-center md:mt-10 mt-5">
      <div class="w-5/12 h-0.5 bg-gray-200 rounded-full"></div>
   </div>

   <div class="flex md:flex-row flex-col mt-10 md:mt-0 gap-2 md:gap-0">
      <div class="w-full md:h-20  flex md:items-end justify-center md:justify-start">
         @foreach(\App\Models\Contact::where('location', 'footer')->get() as $contact)
         <a href="{{$contact->url}}" class="w-9 h-9" target="_blank">
            <img src="{{ asset('storage/' . $contact->image) }}" alt="">
         </a>
         @endforeach
      </div>

      <div class="w-full md:h-20 flex md:items-end justify-center md:justify-end">
         <p class="text-center">Copyright © 2026 PT. UWAIS BORNEO GROUP</p>
      </div>
   </div>

</div>
