<nav x-data="{ open: false }" class="bg-white border-b border-gray-100">
    <!-- Primary Navigation Menu -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex">
                <!-- Logo -->
                <div class="shrink-0 flex items-center">
                    <a href="{{ url('/') }}" target="_blank">
                        <x-application-logo class="block h-9 w-auto fill-current text-gray-800" />
                    </a>
                </div>

                <!-- Navigation Links -->
                <div class="hidden space-x-8 sm:-my-px sm:ms-10 sm:flex">
                    <x-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard')">
                        {{ __('Dashboard') }}
                    </x-nav-link>

                    <!-- Homes -->
                    <div class="hidden sm:flex sm:items-center sm:ms-6">
                        <x-dropdown align="left" width="48">
                            <x-slot name="trigger">
                                <button class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition ease-in-out duration-150">
                                    <div>{{ __('Home') }}</div>

                                    <div class="ms-1">
                                        <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                </button>
                             </x-slot>

                            <x-slot name="content">
                                <x-dropdown-link :href="route('banner.index',['location' => 'home'])" :active="request()->routeIs('banner.*')">
                                    {{ __('Banner') }}
                                </x-dropdown-link>

                                <x-dropdown-link :href="route('vision.index',['location' => 'home'])" :active="request()->routeIs('vision.*')">
                                    {{ __('Visi') }}
                                </x-dropdown-link>

                                <x-dropdown-link :href="route('service.index')" :active="request()->routeIs('service.*')">
                                    {{ __('Layanan') }}
                                </x-dropdown-link>

                                <x-dropdown-link :href="route('competency.index')" :active="request()->routeIs('competency.*')">
                                    {{ __('Keunggulan') }}
                                </x-dropdown-link>
                            </x-slot>
                        </x-dropdown>
                    </div>

                    <!-- abouts -->
                    <div class="hidden sm:flex sm:items-center sm:ms-6">
                        <x-dropdown align="left" width="48">
                            <x-slot name="trigger">
                                <button class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition ease-in-out duration-150">
                                    <div>{{ __('About') }}</div>

                                    <div class="ms-1">
                                        <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                </button>
                             </x-slot>

                            <x-slot name="content">
                                <x-dropdown-link :href="route('banner.index',['location' => 'about'])" :active="request()->routeIs('banner.*')">
                                    {{ __('Banner') }}
                                </x-dropdown-link>

                                 <x-dropdown-link :href="route('abouts.index')" :active="request()->routeIs('abouts.*')">
                                    {{ __('About Us') }}
                                </x-dropdown-link>

                                <x-dropdown-link :href="route('vision.index',['location' => 'about'])" :active="request()->routeIs('vision.*')">
                                    {{ __('Visi') }}
                                </x-dropdown-link>

                                <x-dropdown-link :href="route('philosophy.index')" :active="request()->routeIs('philosophy.*')">
                                    {{ __('philosophy') }}
                                </x-dropdown-link>
                                <x-dropdown-link :href="route('imagecategory.index')" :active="request()->routeIs('imagecategory.*')">
                                    {{ __('Image') }}
                                </x-dropdown-link>
                                <x-dropdown-link :href="route('partner.index')" :active="request()->routeIs('partner.*')">
                                    {{ __('Partner') }}
                                </x-dropdown-link>
                            </x-slot>
                        </x-dropdown>
                    </div>

                    <!-- Product -->
                    <div class="hidden sm:flex sm:items-center sm:ms-6">
                        <x-dropdown align="left" width="48">
                            <x-slot name="trigger">
                                <button class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition ease-in-out duration-150">
                                    <div>{{ __('Product') }}</div>

                                    <div class="ms-1">
                                        <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                </button>
                             </x-slot>

                            <x-slot name="content">
                                <x-dropdown-link :href="route('banner.index')" :active="request()->routeIs('banner.*')">
                                    {{ __('Banner') }}
                                </x-dropdown-link>

                                 <x-dropdown-link :href="route('internetpackage.index')" :active="request()->routeIs('internetpackage.*')">
                                    {{ __('Internet Package') }}
                                </x-dropdown-link>

                                <x-dropdown-link :href="route('cloudservice.index')" :active="request()->routeIs('cloudservice.*')">
                                    {{ __('Cloud Service') }}
                                </x-dropdown-link>
                            </x-slot>
                        </x-dropdown>
                    </div>

                    <!-- contacts -->
                    <div class="hidden sm:flex sm:items-center sm:ms-6">
                        <x-dropdown align="left" width="48">
                            <x-slot name="trigger">
                                <button class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition ease-in-out duration-150">
                                    <div>{{ __('Contact') }}</div>

                                    <div class="ms-1">
                                        <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                </button>
                             </x-slot>

                            <x-slot name="content">
                                <x-dropdown-link :href="route('banner.index',['location' => 'contact'])" :active="request()->routeIs('banner.*')">
                                    {{ __('Banner') }}
                                </x-dropdown-link>

                                 <x-dropdown-link :href="route('contact.index')" :active="request()->routeIs('contact.*')">
                                    {{ __('Kontak') }}
                                </x-dropdown-link>
                            </x-slot>
                        </x-dropdown>
                    </div>    
                </div>

            </div>

            <!-- Settings Dropdown -->
            <div class="hidden sm:flex sm:items-center sm:ms-6">
                <x-dropdown align="right" width="48">
                    <x-slot name="trigger">
                        <button class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition ease-in-out duration-150">
                            <div>{{ Auth::user()->name }}</div>

                            <div class="ms-1">
                                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </button>
                    </x-slot>

                    <x-slot name="content">
                        <x-dropdown-link :href="route('profile.edit')">
                            {{ __('Profile') }}
                        </x-dropdown-link>

                        @if(Auth::user()->isAdmin())
                        <x-dropdown-link :href="route('admin.register')">
                            {{ __('Add Admin') }}
                        </x-dropdown-link>

                        <x-dropdown-link :href="route('users.index')">
                            {{ __('Manage Users') }}
                        </x-dropdown-link>
                        @endif

                        <!-- Authentication -->
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf

                            <x-dropdown-link :href="route('logout')"
                                    onclick="event.preventDefault();
                                                this.closest('form').submit();">
                                {{ __('Log Out') }}
                            </x-dropdown-link>
                        </form>
                    </x-slot>
                </x-dropdown>
            </div>

            <!-- Hamburger -->
            <div class="-me-2 flex items-center sm:hidden">
                <button @click="open = ! open" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 focus:text-gray-500 transition duration-150 ease-in-out">
                    <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path :class="{'hidden': open, 'inline-flex': ! open }" class="inline-flex" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        <path :class="{'hidden': ! open, 'inline-flex': open }" class="hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- Responsive Navigation Menu -->
    <div :class="{'block': open, 'hidden': ! open}" class="hidden sm:hidden">
        <div class="pt-2 pb-3 space-y-1">
            <x-responsive-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard')">
                {{ __('Dashboard') }}
            </x-responsive-nav-link>

            {{-- Responsive Admin Management Links --}}
            <x-responsive-nav-link :href="route('vision.index')">
                {{ __('Visi') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('service.index')">
                {{ __('Layanan') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('competency.index')">
                {{ __('Keunggulan') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('banner.index')">
                {{ __('Banner') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('contact.index')">
                {{ __('Kontak') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('abouts.index')">
                {{ __('About Us') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('partner.index')">
                {{ __('Partner') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('internetpackage.index')">
                {{ __('Internet Package') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('cloudservice.index')">
                {{ __('Cloud Service') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('philosophy.index')" :active="request()->routeIs('philosophy.*')">
                {{ __('philosophy') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('imagecategory.index')" :active="request()->routeIs('imagecategory.*')">
                {{ __('Image') }}
            </x-responsive-nav-link>

            @if(Auth::user()->isAdmin())
            <x-responsive-nav-link :href="route('admin.register')">
                {{ __('Add Admin') }}
            </x-responsive-nav-link>

            <x-responsive-nav-link :href="route('users.index')" :active="request()->routeIs('users.*')">
                {{ __('Manage Users') }}
            </x-responsive-nav-link>
            @endif
        </div>

        <!-- Responsive Settings Options -->
        <div class="pt-4 pb-1 border-t border-gray-200">
            <div class="px-4">
                <div class="font-medium text-base text-gray-800">{{ Auth::user()->name }}</div>
                <div class="font-medium text-sm text-gray-500">{{ Auth::user()->email }}</div>
            </div>

            <div class="mt-3 space-y-1">
                <x-responsive-nav-link :href="route('profile.edit')">
                    {{ __('Profile') }}
                </x-responsive-nav-link>

                <!-- Authentication -->
                <form method="POST" action="{{ route('logout') }}">
                    @csrf

                    <x-responsive-nav-link :href="route('logout')"
                            onclick="event.preventDefault();
                                        this.closest('form').submit();">
                        {{ __('Log Out') }}
                    </x-responsive-nav-link>
                </form>
            </div>
        </div>
    </div>
</nav>