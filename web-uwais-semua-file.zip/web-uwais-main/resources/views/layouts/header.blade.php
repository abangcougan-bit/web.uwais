<div id="header" class="inset-0 sm:fixed w-full sm:h-20 2xl:h-36 z-20 transition-all h-0 duration-300 ease-in-out border-b">
    <div class="sm:flex flex-row w-full h-full hidden p-4 bg-white border-b">

        <div id="logo" class="w-3/5 flex flex-row gap-1 items-center ml-4">
            <img src="{{ asset('assets/images/uwais basic  no bg.png') }}" alt="logo uwais" class="h-14 2xl:h-28">
            <div class="flex flex-col font-sans text-blue-900">
                <p class="font-bold text-3xl 2xl:text-6xl">UWAIS</p>
                <p class="font-bold text-xs 2xl:text-2xl">BORNEO GROUP</p>
            </div>
        </div>
        
        <div id="nav"class="4/5 flex flex-row gap-10 items-center text-xl 2xl:text-4xl font-semibold  text-black">
            <div class="relative group">
                <a class="flex flex-row gap-1 items-center cursor-pointer">
                    <p>Home</p>
                </a>
                <div class="absolute hidden group-hover:block z-10 w-60  bg-white rounded-sm shadow-lg text-gray-500 p-2">
                    <a href="{{ url('/') }}" class="block px-4 py-2 text-sm 2xl:text-xl hover:bg-gray-100">Home</a>
                    <a href="{{ url('/#visi') }}" class="block px-4 py-2 text-sm 2xl:text-xl hover:bg-gray-100 ">Visi</a>
                    <a href="{{ url('/#layanan') }}" class="block px-4 py-2 text-sm 2xl:text-xl hover:bg-gray-100 ">Layanan</a>
                    <a href="{{ url('/#keunggulan') }}" class="block px-4 py-2 text-sm 2xl:text-xl hover:bg-gray-100 ">keunggulan</a>
                </div>
            </div>

            

            <div class="relative group">
                <a class="flex flex-row gap-1 items-center cursor-pointer">
                    <p>About</p>
                </a>
                <div class="absolute hidden group-hover:block z-10 w-60 bg-white rounded-sm shadow-lg text-gray-500 p-2">
                    <a href="{{ url('/about') }}" class="block px-4 py-2 text-sm 2xl:text-xl hover:bg-gray-100">About</a>
                    <a href="{{ url('/about#profile') }}" class="block px-4 py-2 text-sm 2xl:text-xl hover:bg-gray-100 ">Profile</a>
                    <a href="{{ url('/about#visiMisi') }}" class="block px-4 py-2 text-sm 2xl:text-xl hover:bg-gray-100 ">Vision & Mision</a>
                    <a href="{{ url('/about#filosofi') }}" class="block px-4 py-2 text-sm 2xl:text-xl hover:bg-gray-100 ">Phylosophy</a>
                    <a href="{{ url('/about#galeri') }}" class="block px-4 py-2 text-sm 2xl:text-xl hover:bg-gray-100 ">Galery</a>
                    <a href="{{ url('/about#support') }}" class="block px-4 py-2 text-sm 2xl:text-xl hover:bg-gray-100 ">Support</a>
                    
                </div>
            </div>

            <div class="relative group ">
                <a class="flex flex-row gap-1 items-center cursor-pointer">
                    <p>Product</p>
                </a>
                <div class="absolute hidden group-hover:block z-10 w-60 2xl:w-72 bg-white rounded-sm shadow-lg text-gray-500 p-2">
                    <a href="{{ url('/internetpackage') }}" class="block px-4 py-2 text-sm 2xl:text-xl hover:bg-gray-100">Internet Service Provider</a>
                    <a href="{{ url('/cloudservice') }}" class="block px-4 py-2 text-sm 2xl:text-xl hover:bg-gray-100">Cloud Service</a>
                    
                    
                </div>
            </div>

            <a href="{{ url('/contact') }}" class="cursor-pointer">Contact</a>
            </div>

    </div>

    <!--header mobile-->
    <div class="flex flex-row w-full h-16 border-b sm:hidden gap-4 bg-white">

        <div class="w-3/4 flex flex-row gap-1 items-center pl-4">
            <img src="{{ asset('assets/images/uwais basic  no bg.png') }}" alt="logo uwais" class="h-12">
            <div class="flex flex-col gap-0 font-sans text-blue-900">
            <p class="font-bold text-3xl">UWAIS</p>
            <p class="font-bold text-xs">BORNEO GROUP</p></div>
        </div>

        <div id="threeBars" class="flex items-center ml-4">
            <svg class="bg-black rounded-xl w-10 h-10 text-white dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" stroke-linecap="round" stroke-width="2" d="M5 7h14M5 12h14M5 17h14"/>
            </svg>
        </div>

        
    </div>

    <div id="modal" class="w-full h-screen absolute bg-black/80 hidden p-4 text-white">
        <div class="w-full h-full flex flex-col gap-4">
           <div class="flex justify-center items-center p-4 rounded-sm hover:bg-white/40">
                 <a href="{{ url('/') }}">Home</a>
           </div>
           <div class="flex justify-center items-center p-4 rounded-sm hover:bg-white/40">
                 <a href="{{ url('/about') }}">About</a>
           </div>
           <div class="flex justify-center items-center p-4 rounded-sm hover:bg-white/40">
                 <a href="{{ url('/internetpackage') }}">Internet Service Provider</a>
           </div>
           <div class="flex justify-center items-center p-4 rounded-sm hover:bg-white/40">
                 <a href="{{ url('/cloudservice') }}">Cloud service</a>
           </div>
           <div class="flex justify-center items-center p-4 rounded-sm hover:bg-white/40">
                 <a href="{{ url('/contact') }}">Contact</a>
           </div>

        </div>
    </div>

</div>
@push('scripts')
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const header = document.getElementById("header");
        const nav = document.getElementById("nav");

        let lastScrollY = window.scrollY;
        let isScrollingDown = true;
        window.addEventListener("scroll", function () {
            const currentScrollY = window.scrollY;
            
            if (currentScrollY < lastScrollY) {
                
                isScrollingDown = false;
                header.classList.remove("-translate-y-full");
                header.classList.add("translate-y-0");
            } else {
                isScrollingDown = true;
                 header.classList.add("-translate-y-full");
                header.classList.remove("translate-y-0");
            }
            // Update posisi scroll terakhir
            lastScrollY = currentScrollY;
            
        });

        let bar = document.getElementById("threeBars");
        bar.addEventListener("click", function () {
            let modal = document.getElementById("modal");
           modal.classList.toggle("block");
           modal.classList.toggle("hidden");
        });

    });
</script>
@endpush

<!--

-->
