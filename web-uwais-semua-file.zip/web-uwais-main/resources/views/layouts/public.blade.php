<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title') | Uwais Borneo Group</title>
        @stack('styles')
        
        <link rel="icon" href="{{ asset('assets/images/uwais basic  no bg.png') }}" type="jpg">
    

    </head>
    <body class="font-plus-jakarta-sans antialiased overflow-x-hidden w-full h-full">
        <!-- Header -->
         
        @hasSection('header')
            <header>
                @yield('header')
            </header>
        @else
            @include('layouts.header')
        @endif
        
        <!-- Main Content -->
        <main class="mt-16 sm:mt-0">
            @yield('content')
        </main>
        
        <!-- Footer -->
         <footer>
        @hasSection('footer')
            <footer>
                @yield('footer')
            </footer>
        @else
            @include('layouts.footer')
        @endif
        </footer>
        @vite(['resources/css/app.css', 'resources/js/app.js'])
        @stack('scripts')
    </body>
</html>