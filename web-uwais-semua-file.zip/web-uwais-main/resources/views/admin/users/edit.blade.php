<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Edit User') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form action="{{ route('users.update', $user->id) }}" method="POST">
                        @csrf
                        @method('PATCH')
                        
                        <div class="max-w-xl">
                            {{-- Nama --}}
                            <div class="mt-4">
                                <x-input-label for="name" :value="__('Nama')" />
                                <x-text-input id="name" class="block mt-1 w-full" type="text" name="name" :value="old('name', $user->name)" required autofocus />
                                <x-input-error :messages="$errors->get('name')" class="mt-2" />
                            </div>

                            {{-- Email --}}
                            <div class="mt-4">
                                <x-input-label for="email" :value="__('Email')" />
                                <x-text-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email', $user->email)" required />
                                <x-input-error :messages="$errors->get('email')" class="mt-2" />
                            </div>

                            {{-- Role --}}
                            <div class="mt-4">
                                <x-input-label :value="__('Role')" />
                                <div class="flex items-center gap-4 mt-2">
                                    <input type="radio" name="role" id="role_admin" value="admin" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" {{ old('role', $user->role) == 'admin' ? 'checked' : '' }}>
                                    <label for="role_admin" class="text-sm text-gray-900">Admin</label>

                                    <input type="radio" name="role" id="role_editor" value="editor" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" {{ old('role', $user->role) == 'editor' ? 'checked' : '' }}>
                                    <label for="role_editor" class="text-sm text-gray-900">Editor</label>
                                </div>
                                <x-input-error :messages="$errors->get('role')" class="mt-2" />
                            </div>

                            <div class="mt-8 border-t pt-4">
                                <p class="text-sm text-gray-600 mb-4 italic">Kosongkan password jika tidak ingin mengubahnya.</p>
                                
                                {{-- Password --}}
                                <div class="mt-4">
                                    <x-input-label for="password" :value="__('Password Baru')" />
                                    <x-text-input id="password" class="block mt-1 w-full" type="password" name="password" />
                                    <x-input-error :messages="$errors->get('password')" class="mt-2" />
                                </div>

                                {{-- Confirm Password --}}
                                <div class="mt-4">
                                    <x-input-label for="password_confirmation" :value="__('Konfirmasi Password Baru')" />
                                    <x-text-input id="password_confirmation" class="block mt-1 w-full" type="password" name="password_confirmation" />
                                    <x-input-error :messages="$errors->get('password_confirmation')" class="mt-2" />
                                </div>
                            </div>
                        </div>

                        {{-- Tombol Aksi --}}
                        <div class="flex items-center justify-start mt-6">
                            <x-primary-button>
                                {{ __('Perbarui User') }}
                            </x-primary-button>
                            <a href="{{route('users.index')}}" class="ms-4 underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                {{ __('Batal') }}
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
