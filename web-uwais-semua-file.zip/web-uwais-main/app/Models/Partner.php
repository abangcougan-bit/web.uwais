<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Partner extends Model
{
    //
    use HasFactory;

    protected $table = 'partners';

    protected $fillable=[
        'title',
        'description',
        'is_active',
    ];

    public function partnerimages()
    {
        return $this->hasMany(Partnerimage::class, 'partners_id');
    }
    
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}
