<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\Partner;
class Partnerimage extends Model
{
    //
     use HasFactory;

    protected $fillable = [
        'partners_id', 
        'image',
    ];

    public function partner() 
    {
        return $this->belongsTo(Partner::class, 'partners_id'); 
    }
}
