<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Imagecategory extends Model
{
    //
    use HasFactory;

    protected $table = 'imagecategories';

    protected $fillable=[
        'title',
        'description',
        'is_active',
    ];

    public function images()
    {
        return $this->hasMany(Image::class, 'imagecategories_id');
    }
    
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}
