<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Internetpackage; 

class Feature extends Model
{
    use HasFactory;

    protected $fillable = [
        'internetpackage_id', 
        'description',
    ];

    public function internetpackage() 
    {
        return $this->belongsTo(Internetpackage::class); 
    }
}