<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Philosophy extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'image',
        'description',
        'is_active',
    ];

    /**
     * Scope a query to only include active philosophies.
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}