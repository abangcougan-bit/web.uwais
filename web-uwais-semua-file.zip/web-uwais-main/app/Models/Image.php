<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\Imagecategory;

class Image extends Model
{
    //
    use HasFactory;

    protected $fillable = [
        'imagecategories_id', 
        'image',
    ];

    public function imagecategory() 
    {
        return $this->belongsTo(Imagecategory::class, 'imagecategories_id'); 
    }
}
