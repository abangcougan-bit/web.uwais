<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Internetpackage extends Model
{
    use HasFactory;

    protected $table = 'internetpackages';

    protected $fillable=[
        'title',
        'description',
        'order',
        'price',
        'period',
        'location',
        'is_active',
    ];

    public function features()
    {
        return $this->hasMany(Feature::class);
    }
}
