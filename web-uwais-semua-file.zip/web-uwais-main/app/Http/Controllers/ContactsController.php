<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Models\Contact;
use Illuminate\Support\Facades\Storage;

class ContactsController extends Controller
{
    private $locations = ['footer', 'contact'];
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        //
        $query = Contact::query();

        if ($request->filled('location')) {
            $query->where('location', $request->location);
        }

        $contacts = $query->orderBy('location')->get();
        
        return view('contact.index', [
            'contacts' => $contacts,
            'locations' => $this->locations, // Still pass for create/edit forms
            'selectedLocation' => $request->location // Pass selected location to view
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('contact.create', ['locations' => $this->locations]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'title' => 'required',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'description'=>'required',
            'location' => ['required', Rule::in($this->locations)],
            'url'=> 'required',
        ]);

        if ($request->hasFile('image')) {
        $imagePath = $request->file('image')->store('contacts', 'public');
        
        Contact::create([
            'title' => $request->title,
            'image' => $imagePath,
            'description' => $request->description,
            'location' => $request->location,
            'url' => $request->url,
        ]);
    }

        return redirect()->route('contact.index', ['location' => request('location')])
        ->with('success','berhasil menambahkan data');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $contact = Contact::findOrFail($id);
        return view('contact.show',compact('contact'));

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $contact = Contact::findOrFail($id);
        return view('contact.edit', [
            'contact' => $contact,
            'locations' => $this->locations
        ]);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
{
    $contact = Contact::findOrFail($id);

    $request->validate([
        'title' => 'nullable',
        'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // ← Validasi gambar
        'description' => 'nullable',
        'location' => ['nullable', Rule::in($this->locations)],
        'url' => 'nullable',
    ]);

    $data = [
        'title' => $request->title,
        'description' => $request->description,
        'url' => $request->url,
        'location' => $request->location,
    ];

    // Jika ada upload gambar baru
    if ($request->hasFile('image')) {
        // Hapus gambar lama jika ada
        if ($contact->image && Storage::exists('public/' . $contact->image)) {
            Storage::delete('public/' . $contact->image);
        }
        
        // Upload gambar baru
        $imagePath = $request->file('image')->store('contacts', 'public');
        $data['image'] = $imagePath;
    }

    $contact->update($data);

    return redirect()->route('contact.index', ['location' => request('location')])->with('success','berhasil mengupdate data');
}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
{
    $contact = Contact::findOrFail($id);
    
    // Hapus gambar dari storage
    if ($contact->image && Storage::exists('public/' . $contact->image)) {
        Storage::delete('public/' . $contact->image);
    }
    
    $contact->delete();

    return redirect()->route('contact.index', ['location' => $contact->location])->with('success','berhasil menghapus data');
}
}
