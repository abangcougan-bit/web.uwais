<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Internetpackage;
use Illuminate\Validation\Rule;

class InternetpackagesController extends Controller 
{
    private $locations = ['Paket_Dedicate', 'Paket_Dedicate_Lite', 'Paket_Boardband'];
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {  
        $query = Internetpackage::query();

        if ($request->filled('location')) {
            $query->where('location', $request->location);
        }

        $internetpackages = $query->orderBy('location')->orderBy('order', 'asc')->with('features')->get();
        
        return view('internetpackages.index', [
            'internetpackages' => $internetpackages,
            'locations' => $this->locations, // Still pass for create/edit forms
            'selectedLocation' => $request->location // Pass selected location to view
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('internetpackages.create',['locations' => $this->locations]); 
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title'=>'required',
            'description'=>'required',
            'order'=>'required',
            'price'=>'required',
            'period'=>'required',
            'features' => 'array', 
            'features.*' => 'string|max:255',
            'location' => ['required', Rule::in($this->locations)],
            'is_active' => 'boolean', // Add validation for is_active
        ]);

        $internetpackage = Internetpackage::create([ 
            'title'=> $request->title,
            'description'=> $request->description,
            'order'=> $request->order,
            'price'=> $request->price,
            'period'=> $request->period,
            'location' => $request->location,
            'is_active' => $request->has('is_active'), // Handle is_active
        ]);

        // Simpan fitur-fitur baru
        if ($request->has('features') && is_array($request->features)) {
            foreach ($request->features as $featureDescription) {
                if (!empty($featureDescription)) {
                    $internetpackage->features()->create(['description' => $featureDescription]); 
                }
            }
        }

        return redirect()->route('internetpackage.index', ['location' => request('location')])
                        ->with('success','berhasil menambahkan data'); 
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $internetpackage = Internetpackage::with('features')->findOrFail($id); 
        return view('internetpackages.show',compact('internetpackage')); 
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $internetpackage = Internetpackage::with('features')->findOrFail($id); 
        return view('internetpackages.edit',[
            'internetpackage' => $internetpackage,
            'locations' => $this->locations
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $internetpackage = Internetpackage::findOrFail($id); 

        $request->validate([
            'title' => 'nullable',
            'description' => 'nullable',
            'order' => 'nullable',
            'price' => 'nullable',
            'period' => 'nullable',
            'features' => 'array',
            'features.*' => 'string|max:255',
            'location' => ['nullable', Rule::in($this->locations)],
            'is_active' => 'boolean', // Add validation for is_active
        ]);

        $internetpackage->update([ 
            'title'=> $request->title,
            'description'=> $request->description,
            'order' => $request->order,
            'price'=> $request->price,
            'period'=> $request->period,
            'location'=> $request->location,
            'is_active' => $request->has('is_active'), // Handle is_active
        ]);

        // Hapus fitur-fitur lama dan simpan yang baru
        $internetpackage->features()->delete(); 
        if ($request->has('features') && is_array($request->features)) {
            foreach ($request->features as $featureDescription) {
                if (!empty($featureDescription)) {
                    $internetpackage->features()->create(['description' => $featureDescription]); 
                }
            }
        }

        return redirect()->route('internetpackage.index',['location' => request('location')]
        )->with('success','berhasil mengupdate data'); 
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $internetpackage = Internetpackage::findOrFail($id); 
        $internetpackage->delete();

        return redirect()->route('internetpackage.index',['location' => $internetpackage->location])
        ->with('success','berhasil menghapus data'); 
    }
}
