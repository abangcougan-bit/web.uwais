<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\About;

class AboutsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
         $abouts = About::all();
        return view('abouts.index',compact('abouts'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('abouts.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'title'=>'required|string|max:255',
            'description'=>'required|string',
            'is_active' => 'boolean', // Add validation for is_active
        ]);

        About::create([
            'title' => $request->title,
            'description' => $request->description,
            'is_active' => $request->input('is_active') == '1', // Handle is_active
        ]);

        return redirect()->route('abouts.index')->with('success','berhasil menambahkan data');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $about = About::findOrFail($id);
        return view('abouts.show',compact('about'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $about = About::findOrFail($id);
        return view('abouts.edit',compact('about'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
        $about = About::findOrFail($id);

        $request->validate([
            'title' => 'nullable|string|max:255',  
            'description' => 'nullable|string',
            'is_active' => 'boolean', // Add validation for is_active
        ]);
        $about->update([
            'title' => $request->title,
            'description' => $request->description,
            'is_active' => $request->input('is_active') == '1', // Handle is_active
        ]);

    return redirect()->route('abouts.index')->with('success','berhasil mengupdate data');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        $about = About::findOrFail($id);
        $about->delete();

    return redirect()->route('abouts.index')->with('success','berhasil menghapus data');
    }
}
