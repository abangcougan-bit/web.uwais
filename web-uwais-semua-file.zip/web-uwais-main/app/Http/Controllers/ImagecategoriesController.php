<?php

namespace App\Http\Controllers;

use App\Models\Imagecategory;
use App\Models\Image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ImagecategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {  
        $imagecategories = Imagecategory::with('images')->get();
        return view('imagecategory.index', compact('imagecategories'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('imagecategory.create'); 
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|min:3|max:255',
            'description' => 'required',
            'images' => 'required|array|min:1',
            'images.*' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $imagecategory = Imagecategory::create([ 
            'title' => $request->title,
            'description' => $request->description,
            'is_active' => $request->input('is_active') == '1',
        ]);

        // Simpan gambar
        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $image) {
                $imagePath = $image->store('images', 'public');
                
                $imagecategory->images()->create([
                    'image' => $imagePath,
                ]);
            }
        }

        return redirect()->route('imagecategory.index')
                        ->with('success', 'berhasil menambahkan data'); 
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $imagecategory = Imagecategory::with('images')->findOrFail($id); 
        return view('imagecategory.show', compact('imagecategory')); 
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $imagecategory = Imagecategory::with('images')->findOrFail($id); 
        return view('imagecategory.edit', compact('imagecategory')); 
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $imagecategory = Imagecategory::findOrFail($id); 

        $request->validate([
            'title' => 'nullable|min:3|max:255',
            'description' => 'nullable',
            'images' => 'nullable|array',
            'images.*' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $imagecategory->update([ 
            'title' => $request->title,
            'description' => $request->description,
            'is_active' => $request->input('is_active') == '1',
        ]);

        // Tambah gambar baru jika ada
        if ($request->hasFile('images')) {
            // Simpan gambar baru
            foreach ($request->file('images') as $image) {
                // Pastikan file gambar valid sebelum melanjutkan
                if ($image->isValid()) {
                    $imagePath = $image->store('images', 'public');
                    
                    $imagecategory->images()->create([
                        'image' => $imagePath,
                    ]);
                }
            }
        }

        return redirect()->route('imagecategory.index')
                        ->with('success', 'berhasil mengupdate data'); 
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $imagecategory = Imagecategory::findOrFail($id);
        
        // Hapus semua file gambar dari storage
        foreach ($imagecategory->images as $image) {
            if ($image->image && Storage::exists('public/' . $image->image)) {
                Storage::delete('public/' . $image->image);
            }
        }
        
        // Hapus data
        $imagecategory->images()->delete();
        $imagecategory->delete();

        return redirect()->route('imagecategory.index')
                        ->with('success', 'berhasil menghapus data'); 
    }
    public function destroyImage(Image $image)
    {
        // Hapus file dari storage
        if ($image->image && Storage::disk('public')->exists($image->image)) {
            Storage::disk('public')->delete($image->image);
        }

        // Hapus record dari database
        $image->delete();

        return back()->with('success', 'Gambar berhasil dihapus.');
    }
    
    
}