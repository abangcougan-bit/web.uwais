<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Storage;
use App\Models\Cloudservice;

class CloudservicesController extends Controller
{
    // Define locations centrally to be used in validation and views
    private $locations = ['web_desa','hosting','vps','co-location'];

    /**
     * Display a listing of the resource.
     * Always displays all cloudservices, filter removed.
     */
    public function index(Request $request)
    {
        $query = Cloudservice::query();

        if ($request->filled('location')) {
            $query->where('location', $request->location);
        }

        $cloudservices = $query->orderBy('location')->get();
        
        return view('cloudservice.index', [
            'cloudservices' => $cloudservices,
            'locations' => $this->locations, // Still pass for create/edit forms
            'selectedLocation' => $request->location // Pass selected location to view
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('cloudservice.create', ['locations' => $this->locations]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'title' => 'required|min:3|max:255',
            'description'=>'required',
            'location' => ['required', Rule::in($this->locations)],
        ]);

        $imagePath = $request->file('image')->store('cloudservices', 'public');
        
        Cloudservice::create([
            'image' => $imagePath,
            'title' => $request->title,
            'description' => $request->description,
            'location' => $request->location,
            'is_active' => $request->input('is_active') == '1', // Read value from radio button
        ]);
        
        return redirect()->route('cloudservice.index', ['location' => request('location')]) // Removed location parameter
                         ->with('success', 'berhasil menambahkan data');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $cloudservice = Cloudservice::findOrFail($id);
        return view('cloudservice.show',compact('cloudservice'));
        

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $cloudservice = Cloudservice::findOrFail($id);
        return view('cloudservice.edit', [
            'cloudservice' => $cloudservice,
            'locations' => $this->locations
        ]);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
{
        $cloudservice = Cloudservice::findOrFail($id);
        $request->validate([
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'title' => 'nullable',
            'description' => 'nullable',
            'location' => ['nullable', Rule::in($this->locations)],
        ]);

        $data = $request->only(['title', 'description', 'location']);
        $data['is_active'] = $request->input('is_active') == '1';

        if ($request->hasFile('image')) {
            // Delete old image if it exists
            if ($cloudservice->image && Storage::exists('public/' . $cloudservice->image)) {
                Storage::delete('public/' . $cloudservice->image);
            }
            
            // Store new image
            $data['image'] = $request->file('image')->store('cloudservices', 'public');
        }

        $cloudservice->update($data);

        return redirect()->route('cloudservice.index', ['location' => request('location')]) // Removed location parameter
                         ->with('success', 'berhasil mengupdate data');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        // Removed $location as it's no longer needed for redirect
        $cloudservice = Cloudservice::findOrFail($id);
        // Delete the image from storage
        if ($cloudservice->image && Storage::exists('public/' . $cloudservice->image)) {
            Storage::delete('public/' . $cloudservice->image);
        }
        
        $cloudservice->delete();

        return redirect()->route('cloudservice.index', ['location' => $cloudservice->location]) // Removed location parameter
                         ->with('success', 'berhasil menghapus data');
    }
}
