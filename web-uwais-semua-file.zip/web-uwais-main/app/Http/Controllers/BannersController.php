<?php

namespace App\Http\Controllers;

use App\Models\Banner;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class BannersController extends Controller
{
    // Define locations centrally to be used in validation and views
    private $locations = ['home', 'about', 'internet_package','cloud_service', 'contact'];

    /**
     * Display a listing of the resource.
     * Always displays all banners, filter removed.
     */
    public function index(Request $request)
    {
        $query = Banner::query();

        if ($request->filled('location')) {
            $query->where('location', $request->location);
        }

        $banners = $query->orderBy('location')->get();
        
        return view('banner.index', [
            'banners' => $banners,
            'locations' => $this->locations, // Still pass for create/edit forms
            'selectedLocation' => $request->location // Pass selected location to view
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('banner.create', ['locations' => $this->locations]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'title' => 'required|min:3|max:255',
            'description'=>'required',
            'location' => ['required', Rule::in($this->locations)],
        ]);

        $imagePath = $request->file('image')->store('banners', 'public');
        
        Banner::create([
            'image' => $imagePath,
            'title' => $request->title,
            'description' => $request->description,
            'location' => $request->location,
            'is_active' => $request->input('is_active') == '1', // Read value from radio button
        ]);
        
        return redirect()->route('banner.index', ['location' => request('location')]) // Removed location parameter
                         ->with('success', 'berhasil menambahkan data');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $banner = Banner::findOrFail($id);
        return view('banner.show',compact('banner'));
        

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $banner = Banner::findOrFail($id);
        return view('banner.edit', [
            'banner' => $banner,
            'locations' => $this->locations
        ]);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
{
        $banner = Banner::findOrFail($id);
        $request->validate([
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'title' => 'nullable',
            'description' => 'nullable',
            'location' => ['nullable', Rule::in($this->locations)],
        ]);

        $data = $request->only(['title', 'description', 'location']);
        $data['is_active'] = $request->input('is_active') == '1';

        if ($request->hasFile('image')) {
            // Delete old image if it exists
            if ($banner->image && Storage::exists('public/' . $banner->image)) {
                Storage::delete('public/' . $banner->image);
            }
            
            // Store new image
            $data['image'] = $request->file('image')->store('banners', 'public');
        }

        $banner->update($data);

        return redirect()->route('banner.index', ['location' => request('location')]) // Removed location parameter
                         ->with('success', 'berhasil mengupdate data');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        // Removed $location as it's no longer needed for redirect
        $banner = Banner::findOrFail($id);
        // Delete the image from storage
        if ($banner->image && Storage::exists('public/' . $banner->image)) {
            Storage::delete('public/' . $banner->image);
        }
        
        $banner->delete();

        return redirect()->route('banner.index', ['location' => $banner->location]) // Removed location parameter
                         ->with('success', 'berhasil menghapus data');
    }
}