<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Competency;
use Illuminate\Support\Facades\Storage;

class CompetenciesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $competencies = Competency::all();
        return view('competency.index',compact('competencies'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('competency.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'title'=>'required',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'description'=>'required',
            'is_active' => 'boolean', // Add validation for is_active
        ]);

        if ($request->hasFile('image')) {
        $imagePath = $request->file('image')->store('competencies', 'public');
        
        Competency::create([
            'title' => $request->title,
            'image' => $imagePath,
            'description' => $request->description,
            'is_active' => $request->input('is_active') == '1', // Handle is_active
        ]);
    }

        return redirect()->route('competency.index')->with('success','berhasil menambahkan data');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $competency = Competency::findOrFail($id);
        return view('competency.show',compact('competency'));

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $competency = Competency::findOrFail($id);
        return view('competency.edit',compact('competency'));

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
{
    $competency = Competency::findOrFail($id);

    $request->validate([
        'title' => 'nullable',
        'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Validasi gambar
        'description' => 'nullable',
        'is_active' => 'boolean', // Add validation for is_active
    ]);

    $data = [
        'title' => $request->title,
        'description' => $request->description,
        'is_active' => $request->input('is_active') == '1', // Handle is_active
    ];

    // Jika ada upload gambar baru
    if ($request->hasFile('image')) {
        // Hapus gambar lama jika ada
        if ($competency->image && Storage::exists('public/' . $competency->image)) {
            Storage::delete('public/' . $competency->image);
        }
        
        // Upload gambar baru
        $imagePath = $request->file('image')->store('competencies', 'public');
        $data['image'] = $imagePath;
    }

    $competency->update($data);

    return redirect()->route('competency.index')->with('success','berhasil mengupdate data');
}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
{
    $competency = Competency::findOrFail($id);
    
    // Hapus gambar dari storage
    if ($competency->image && Storage::exists('public/' . $competency->image)) {
        Storage::delete('public/' . $competency->image);
    }
    
    $competency->delete();

    return redirect()->route('competency.index')->with('success','berhasil menghapus data');
}
}