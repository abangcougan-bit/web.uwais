<?php

namespace App\Http\Controllers;

use App\Models\Partner;
use App\Models\Partnerimage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
class PartnersController extends Controller
{
    //
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {  
        $partners = Partner::with('partnerimages')->get();
        return view('partner.index', compact('partners'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('partner.create'); 
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|min:3|max:255',
            'description' => 'required',
            'partnerimages' => 'required|array|min:1',
            'partnerimages.*' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $partner = Partner::create([ 
            'title' => $request->title,
            'description' => $request->description,
            'is_active' => $request->input('is_active') == '1',
        ]);

        // Simpan gambar
        if ($request->hasFile('partnerimages')) {
            foreach ($request->file('partnerimages') as $image) {
                $imagePath = $image->store('partnerimages', 'public');
                
                $partner->partnerimages()->create([
                    'image' => $imagePath,
                ]);
            }
        }

        return redirect()->route('partner.index')
                        ->with('success', 'berhasil menambahkan data'); 
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $partner = Partner::with('partnerimages')->findOrFail($id); 
        return view('partner.show', compact('partner')); 
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $partner = Partner::with('partnerimages')->findOrFail($id); 
        return view('partner.edit', compact('partner')); 
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $partner = Partner::findOrFail($id); 

        $request->validate([
            'title' => 'nullable|min:3|max:255',
            'description' => 'nullable',
            'partnerimages' => 'nullable|array',
            'partnerimages.*' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $partner->update([ 
            'title' => $request->title,
            'description' => $request->description,
            'is_active' => $request->input('is_active') == '1',
        ]);

        // Tambah gambar baru jika ada
        if ($request->hasFile('partnerimages')) {
            // Simpan gambar baru
            foreach ($request->file('partnerimages') as $image) {
                // Pastikan file gambar valid sebelum melanjutkan
                if ($image->isValid()) {
                    $imagePath = $image->store('partnerimages', 'public');
                    
                    $partner->partnerimages()->create([
                        'image' => $imagePath,
                    ]);
                }
            }
        }

        return redirect()->route('partner.index')
                        ->with('success', 'berhasil mengupdate data'); 
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $partner = Partner::findOrFail($id);
        
        // Hapus semua file gambar dari storage
        foreach ($partner->partnerimages as $image) {
            if ($image->image && Storage::exists('public/' . $image->image)) {
                Storage::delete('public/' . $image->image);
            }
        }
        
        // Hapus data
        $partner->partnerimages()->delete();
        $partner->delete();

        return redirect()->route('partner.index')
                        ->with('success', 'berhasil menghapus data'); 
    }
    public function destroyImage(Partnerimage $partnerimage)
    {
        // Hapus file dari storage
        if ($partnerimage->image && Storage::disk('public')->exists($partnerimage->image)) {
            Storage::disk('public')->delete($partnerimage->image);
        }

        // Hapus record dari database
        $partnerimage->delete();

        return back()->with('success', 'Gambar berhasil dihapus.');
    }
    
    
}
