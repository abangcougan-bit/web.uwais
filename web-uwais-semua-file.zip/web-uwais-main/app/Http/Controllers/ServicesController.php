<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Service;
use Illuminate\Support\Facades\Storage;

class ServicesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $services = Service::all();
        return view('service.index',compact('services'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('service.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'title'=>'required',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'description'=>'required',
            'is_active' => 'boolean', // Add validation for is_active
        ]);

        if ($request->hasFile('image')) {
        $imagePath = $request->file('image')->store('services', 'public');
        
        Service::create([
            'title' => $request->title,
            'image' => $imagePath,
            'description' => $request->description,
            'is_active' => $request->input('is_active') == '1', // Handle is_active
        ]);
    }

        return redirect()->route('service.index')->with('success','berhasil menambahkan data');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $service = Service::findOrFail($id);
        return view('service.show',compact('service'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $service = Service::findOrFail($id);
        return view('service.edit',compact('service'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
        $service = Service::findOrFail($id);

    $request->validate([
        'title' => 'nullable',
        'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        'description' => 'nullable',
        'is_active' => 'boolean', // Add validation for is_active
    ]);

    $data = [
        'title' => $request->title,
        'description' => $request->description,
        'is_active' => $request->input('is_active') == '1', // Handle is_active
    ];

    
    if ($request->hasFile('image')) {
        
        if ($service->image && Storage::exists('public/' . $service->image)) {
            Storage::delete('public/' . $service->image);
        }
        
        // Upload gambar baru
        $imagePath = $request->file('image')->store('services', 'public');
        $data['image'] = $imagePath;
    }

    $service->update($data);

    return redirect()->route('service.index')->with('success','berhasil mengupdate data');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        $service = Service::findOrFail($id);
    
    // Hapus gambar dari storage
    if ($service->image && Storage::exists('public/' . $service->image)) {
        Storage::delete('public/' . $service->image);
    }
    
    $service->delete();

    return redirect()->route('service.index')->with('success','berhasil menghapus data');
    }
}
