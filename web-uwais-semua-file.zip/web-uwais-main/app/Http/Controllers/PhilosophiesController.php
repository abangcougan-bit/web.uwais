<?php

namespace App\Http\Controllers;

use App\Models\Philosophy;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class PhilosophiesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $philosophies = Philosophy::all();
        return view('philosophy.index', compact('philosophies'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('philosophy.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|min:3|max:255',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'description' => 'required',
        ]);

        $imagePath = $request->file('image')->store('philosophies', 'public');
        
        Philosophy::create([
            'title' => $request->title,
            'image' => $imagePath,
            'description' => $request->description,
            'is_active' => $request->input('is_active') == '1',
        ]);
        
        return redirect()->route('philosophy.index')
                         ->with('success', 'Philosophy created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $philosophy = Philosophy::findOrFail($id);
        return view('philosophy.show', compact('philosophy'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $philosophy = Philosophy::findOrFail($id);
        return view('philosophy.edit', compact('philosophy'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $philosophy = Philosophy::findOrFail($id);

        $request->validate([
            'title' => 'nullable|min:3|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'description' => 'nullable',
        ]);

        $data = $request->only(['title', 'description']);
        $data['is_active'] = $request->input('is_active') == '1';

        if ($request->hasFile('image')) {
            if ($philosophy->image && Storage::disk('public')->exists($philosophy->image)) {
                Storage::disk('public')->delete($philosophy->image);
            }
            $data['image'] = $request->file('image')->store('philosophies', 'public');
        }

        $philosophy->update($data);

        return redirect()->route('philosophy.index')
                         ->with('success', 'Philosophy updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $philosophy = Philosophy::findOrFail($id);

        if ($philosophy->image && Storage::disk('public')->exists($philosophy->image)) {
            Storage::disk('public')->delete($philosophy->image);
        }
        
        $philosophy->delete();

        return redirect()->route('philosophy.index')
                         ->with('success', 'Philosophy deleted successfully.');
    }
}