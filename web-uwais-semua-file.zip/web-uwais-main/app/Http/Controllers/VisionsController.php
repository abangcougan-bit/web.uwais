<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Vision;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class VisionsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    private $locations = ['home', 'about'];

    /**
     * Display a listing of the resource.
     * Always displays all banners, filter removed.
     */
    public function index(Request $request)
    {
        $query = Vision::query();

        if ($request->filled('location')) {
            $query->where('location', $request->location);
        }

        $visions = $query->orderBy('location')->get();
        
        return view('vision.index', [
            'visions' => $visions,
            'locations' => $this->locations, // Still pass for create/edit forms
            'selectedLocation' => $request->location // Pass selected location to view
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('vision.create', ['locations' => $this->locations]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'title' => 'required',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'description'=>'required',
            'location' => ['required', Rule::in($this->locations)],
        ]);

        if ($request->hasFile('image')) {
        $imagePath = $request->file('image')->store('visions', 'public');
        
        Vision::create([
            'title' => $request->title,
            'image' => $imagePath,
            'description' => $request->description,
            'location' => $request->location,
            'is_active' => $request->input('is_active') == '1',
        ]);
    }

        return redirect()->route('vision.index',['location' => request('location')])->with('success','berhasil menambahkan data');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $vision = Vision::findOrFail($id);
        return view('vision.show',compact('vision'));

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $vision = Vision::findOrFail($id);
        return view('vision.edit', [
            'vision' => $vision,
            'locations' => $this->locations
        ]);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
{
    $vision = Vision::findOrFail($id);

    $request->validate([
        'title' => 'nullable',
        'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // ← Validasi gambar
        'description' => 'nullable',
        'location' => ['nullable', Rule::in($this->locations)],
    ]);

    $data = $request->only(['title', 'description', 'location']);
    $data['is_active'] = $request->input('is_active') == '1';

    // Jika ada upload gambar baru
    if ($request->hasFile('image')) {
        // Hapus gambar lama jika ada
        if ($vision->image && Storage::exists('public/' . $vision->image)) {
            Storage::delete('public/' . $vision->image);
        }
        
        // Upload gambar baru
        $imagePath = $request->file('image')->store('visions', 'public');
        $data['image'] = $imagePath;
    }

    $vision->update($data);
    

    return redirect()->route('vision.index',['location' => request('location')])->with('success','berhasil mengupdate data');
}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
{
    $vision = Vision::findOrFail($id);
    
    // Hapus gambar dari storage
    if ($vision->image && Storage::exists('public/' . $vision->image)) {
        Storage::delete('public/' . $vision->image);
    }
    
    $vision->delete();

    return redirect()->route('vision.index',['location' => $vision->location])->with('success','berhasil menghapus data');
}
}
